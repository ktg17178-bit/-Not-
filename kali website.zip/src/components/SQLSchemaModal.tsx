import React, { useState } from 'react';
import { dbService } from '../services/db';
import { X, Copy, Check, Database, Server, Key, AlertCircle } from 'lucide-react';

interface SQLSchemaModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SQLSchemaModal: React.FC<SQLSchemaModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [supabaseUrl, setSupabaseUrl] = useState(() => dbService.getSupabaseConfig().url);
  const [supabaseKey, setSupabaseKey] = useState(() => dbService.getSupabaseConfig().anonKey);
  const [connectStatus, setConnectStatus] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  if (!isOpen) return null;

  const sql = dbService.getSQLSchema();

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(sql);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback
    }
  };

  const handleSaveConnection = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsTesting(true);
    setConnectStatus(null);
    const result = await dbService.configureSupabase(supabaseUrl, supabaseKey);
    setIsTesting(false);
    setConnectStatus(result.message);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-3xl bg-[#121212] border border-white/10 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-white">
        {/* Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#ff5a1f]/10 border border-[#ff5a1f]/30 flex items-center justify-center text-[#ff5a1f]">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold tracking-wide text-white">Database & Supabase SQL Schema</h2>
              <p className="text-xs text-zinc-400">PostgreSQL tables for menu_items, bookings, users, and activity_logs</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Supabase Connection Widget */}
          <div className="p-4 rounded-xl bg-black/50 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Server className="w-4 h-4 text-[#ff5a1f]" />
                <h3 className="text-sm font-semibold text-zinc-200">Supabase Cloud Connection (Optional)</h3>
              </div>
              <span className={`text-[11px] px-2.5 py-0.5 rounded-full font-medium ${
                dbService.getSupabaseConfig().isConnected
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                  : 'bg-zinc-800 text-zinc-400 border border-white/5'
              }`}>
                {dbService.getSupabaseConfig().isConnected ? '● Connected' : 'Local Storage Mode'}
              </span>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed">
              The application runs out of the box with resilient browser local persistence. To link a live Supabase project, provide your project URL and anon public key below.
            </p>

            <form onSubmit={handleSaveConnection} className="space-y-3 pt-1">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-zinc-400 mb-1">Project URL</label>
                  <input
                    type="url"
                    placeholder="https://xyz.supabase.co"
                    value={supabaseUrl}
                    onChange={(e) => setSupabaseUrl(e.target.value)}
                    className="w-full bg-[#18181b] border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#ff5a1f]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-zinc-400 mb-1">Anon / Public Key</label>
                  <div className="relative">
                    <input
                      type="password"
                      placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6..."
                      value={supabaseKey}
                      onChange={(e) => setSupabaseKey(e.target.value)}
                      className="w-full bg-[#18181b] border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#ff5a1f]"
                    />
                    <Key className="w-3.5 h-3.5 absolute right-3 top-2.5 text-zinc-500 pointer-events-none" />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                {connectStatus ? (
                  <span className="text-xs text-[#ff5a1f] flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5" />
                    {connectStatus}
                  </span>
                ) : <span />}
                <button
                  type="submit"
                  disabled={isTesting}
                  className="px-4 py-2 rounded-lg bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-semibold transition-colors disabled:opacity-50"
                >
                  {isTesting ? 'Verifying...' : supabaseUrl ? 'Update & Save Credentials' : 'Switch to Local DB'}
                </button>
              </div>
            </form>
          </div>

          {/* SQL Editor Code Block */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-zinc-300">Run in Supabase SQL Editor</span>
                <span className="text-[11px] text-zinc-500">PostgreSQL DDL & Seeds</span>
              </div>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs text-zinc-200 transition-colors border border-white/10 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied to Clipboard!' : 'Copy SQL Script'}</span>
              </button>
            </div>

            <pre className="p-4 rounded-xl bg-black border border-white/10 text-[11px] font-mono text-zinc-300 overflow-x-auto max-h-72 leading-relaxed selection:bg-[#ff5a1f] selection:text-white">
              {sql}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-black/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-white transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
