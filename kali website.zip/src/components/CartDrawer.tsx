import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { X, Plus, Minus, Trash2, ShoppingBag, ArrowRight, CheckCircle2, Sparkles, UtensilsCrossed } from 'lucide-react';
import confetti from 'canvas-confetti';

interface CartDrawerProps {
  onNavigateToMenu: () => void;
  onNavigateToBooking: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ onNavigateToMenu, onNavigateToBooking }) => {
  const {
    items,
    isOpen,
    closeCart,
    removeItem,
    updateQuantity,
    clearCart,
    subtotal,
    tax,
    total
  } = useCart();

  const [orderType, setOrderType] = useState<'dine-in' | 'pre-order'>('dine-in');
  const [tableNumber, setTableNumber] = useState('');
  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [orderCompleted, setOrderCompleted] = useState<{ id: string } | null>(null);

  if (!isOpen) return null;

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    const orderId = `KALI-ORD-${Math.floor(1000 + Math.random() * 9000)}`;
    setOrderCompleted({ id: orderId });

    confetti({
      particleCount: 75,
      spread: 60,
      origin: { y: 0.6 },
      colors: ['#ff5a1f', '#d97706', '#f59e0b', '#ffffff']
    });

    clearCart();
  };

  const handleResetOrder = () => {
    setOrderCompleted(null);
    closeCart();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity duration-300"
        onClick={closeCart}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#121212] border-l border-white/10 text-white flex flex-col shadow-2xl">
          {/* Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#ff5a1f]/10 border border-[#ff5a1f]/30 flex items-center justify-center text-[#ff5a1f]">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-lg font-semibold tracking-wide text-white">Your Tasting Order</h2>
                <p className="text-xs text-zinc-400">
                  {items.length} {items.length === 1 ? 'creation' : 'creations'} selected
                </p>
              </div>
            </div>
            <button
              onClick={closeCart}
              className="p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {orderCompleted ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-4">
                <div className="w-16 h-16 rounded-full bg-[#ff5a1f]/15 border border-[#ff5a1f]/40 flex items-center justify-center text-[#ff5a1f] mb-4">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <span className="text-xs uppercase tracking-widest text-[#ff5a1f] font-semibold mb-1">
                  Order Confirmed
                </span>
                <h3 className="text-2xl font-serif-luxury font-bold text-white mb-2">
                  Compliments to Your Palate
                </h3>
                <p className="text-xs text-zinc-400 max-w-xs mb-4">
                  Reference: <span className="font-mono text-white font-semibold">{orderCompleted.id}</span>
                </p>
                <div className="bg-black/40 border border-white/10 rounded-xl p-4 text-xs text-zinc-300 w-full mb-6 text-left space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Service:</span>
                    <span className="capitalize">{orderType} Tasting</span>
                  </div>
                  {orderType === 'dine-in' && tableNumber && (
                    <div className="flex justify-between">
                      <span className="text-zinc-500">Table:</span>
                      <span>#{tableNumber}</span>
                    </div>
                  )}
                  {guestName && (
                    <div className="flex justify-between">
                      <span className="text-zinc-500">Guest:</span>
                      <span>{guestName}</span>
                    </div>
                  )}
                  <div className="flex justify-between border-t border-white/10 pt-1.5 mt-1.5">
                    <span className="text-zinc-500">Kitchen Status:</span>
                    <span className="text-[#ff5a1f] font-medium">Transmitted to Executive Chef</span>
                  </div>
                </div>

                <div className="space-y-3 w-full">
                  <button
                    onClick={() => {
                      handleResetOrder();
                      onNavigateToBooking();
                    }}
                    className="w-full py-2.5 px-4 rounded-lg bg-[#ff5a1f] text-white text-xs font-semibold hover:bg-[#e04b14] transition-colors flex items-center justify-center gap-2 shadow-lg shadow-[#ff5a1f]/20"
                  >
                    <span>Also Reserve Table Seating</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={handleResetOrder}
                    className="w-full py-2.5 px-4 rounded-lg bg-zinc-900 border border-white/10 text-zinc-300 text-xs font-medium hover:text-white hover:border-white/20 transition-colors"
                  >
                    Close & Return to Dining
                  </button>
                </div>
              </div>
            ) : items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="w-16 h-16 rounded-full bg-zinc-900 border border-white/5 flex items-center justify-center text-zinc-600 mb-4">
                  <UtensilsCrossed className="w-7 h-7" />
                </div>
                <h3 className="text-lg font-medium text-zinc-300 mb-1">Your tasting course is empty</h3>
                <p className="text-xs text-zinc-500 max-w-xs mb-6">
                  Explore our seasonal culinary creations, artisanal wagyu, and bespoke cocktails.
                </p>
                <button
                  onClick={() => {
                    closeCart();
                    onNavigateToMenu();
                  }}
                  className="px-5 py-2.5 rounded-lg bg-[#ff5a1f] text-white text-xs font-semibold hover:bg-[#e04b14] transition-colors"
                >
                  Discover Menu
                </button>
              </div>
            ) : (
              <>
                {/* Items List */}
                <div className="space-y-4">
                  {items.map(({ menuItem, quantity, specialNote }) => (
                    <div
                      key={menuItem.id}
                      className="p-3.5 rounded-xl bg-black/40 border border-white/5 flex gap-3.5 items-center hover:border-white/15 transition-all"
                    >
                      <img
                        src={menuItem.image_url}
                        alt={menuItem.name}
                        className="w-16 h-16 rounded-lg object-cover flex-shrink-0 border border-white/10"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <h4 className="text-sm font-medium text-white truncate">{menuItem.name}</h4>
                          <button
                            onClick={() => removeItem(menuItem.id)}
                            className="text-zinc-500 hover:text-rose-400 p-1 transition-colors"
                            title="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <span className="text-xs text-[#ff5a1f] font-medium">${menuItem.price}</span>
                        {specialNote && (
                          <p className="text-[11px] text-zinc-400 italic truncate mt-0.5">"{specialNote}"</p>
                        )}
                        <div className="flex items-center gap-2 mt-2">
                          <button
                            onClick={() => updateQuantity(menuItem.id, quantity - 1)}
                            className="w-6 h-6 rounded bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center text-xs text-white"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-mono font-medium w-5 text-center text-zinc-200">
                            {quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(menuItem.id, quantity + 1)}
                            className="w-6 h-6 rounded bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center text-xs text-white"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                          <span className="ml-auto text-xs font-semibold text-zinc-200 font-mono">
                            ${(menuItem.price * quantity).toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Service Type Selection */}
                <div className="pt-2 border-t border-white/10">
                  <label className="block text-xs font-medium text-zinc-400 uppercase tracking-wider mb-2">
                    Experience Type
                  </label>
                  <div className="grid grid-cols-2 gap-2 bg-black/40 p-1 rounded-lg border border-white/5">
                    <button
                      type="button"
                      onClick={() => setOrderType('dine-in')}
                      className={`py-2 text-xs font-medium rounded-md transition-all ${
                        orderType === 'dine-in'
                          ? 'bg-[#ff5a1f] text-white shadow-sm'
                          : 'text-zinc-400 hover:text-white'
                      }`}
                    >
                      Dine-In Table
                    </button>
                    <button
                      type="button"
                      onClick={() => setOrderType('pre-order')}
                      className={`py-2 text-xs font-medium rounded-md transition-all ${
                        orderType === 'pre-order'
                          ? 'bg-[#ff5a1f] text-white shadow-sm'
                          : 'text-zinc-400 hover:text-white'
                      }`}
                    >
                      VIP Pre-Order
                    </button>
                  </div>
                </div>

                {/* Checkout Details Form */}
                <form id="cart-order-form" onSubmit={handleCheckout} className="space-y-3">
                  {orderType === 'dine-in' ? (
                    <div>
                      <label className="block text-xs text-zinc-400 mb-1">Table Number</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. 7 or 'Bar 2'"
                        value={tableNumber}
                        onChange={(e) => setTableNumber(e.target.value)}
                        className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ff5a1f]"
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="block text-xs text-zinc-400 mb-1">Guest Phone for Pick-up</label>
                      <input
                        type="tel"
                        required
                        placeholder="+1 (555) 000-0000"
                        value={guestPhone}
                        onChange={(e) => setGuestPhone(e.target.value)}
                        className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ff5a1f]"
                      />
                    </div>
                  )}

                  <div>
                    <label className="block text-xs text-zinc-400 mb-1">Guest Name</label>
                    <input
                      type="text"
                      required
                      placeholder="Your name or surname"
                      value={guestName}
                      onChange={(e) => setGuestName(e.target.value)}
                      className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#ff5a1f]"
                    />
                  </div>
                </form>
              </>
            )}
          </div>

          {/* Footer with Calculations */}
          {!orderCompleted && items.length > 0 && (
            <div className="p-6 border-t border-white/10 bg-[#0e0e0e] space-y-4">
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-zinc-400">
                  <span>Subtotal</span>
                  <span className="font-mono text-zinc-200">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-zinc-400">
                  <span>Hospitality & Culinary Tax (8%)</span>
                  <span className="font-mono text-zinc-200">${tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm font-semibold text-white pt-2 border-t border-white/10">
                  <span>Estimated Total</span>
                  <span className="font-mono text-[#ff5a1f]">${total.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="submit"
                  form="cart-order-form"
                  className="flex-1 py-3 px-4 rounded-lg bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-semibold transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#ff5a1f]/20 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Transmit Order to Kitchen</span>
                </button>
              </div>

              <p className="text-[11px] text-zinc-500 text-center">
                Bespoke service with complimentary valet and sommelier guidance.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
