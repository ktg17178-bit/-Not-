import React from 'react';
import { Award, Clock, MapPin, Phone, Mail, Instagram, ShieldCheck, Database, Wine } from 'lucide-react';

interface FooterProps {
  onSelectTab: (tab: string) => void;
  onOpenSQLModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectTab, onOpenSQLModal }) => {
  return (
    <footer className="bg-[#070707] border-t border-white/10 text-zinc-400 text-xs">
      {/* Top Banner: Accolades */}
      <div className="border-b border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div className="flex flex-col items-center">
            <Award className="w-5 h-5 text-[#ff5a1f] mb-1.5" />
            <span className="text-white font-medium text-xs tracking-wider uppercase">Two Michelin Stars</span>
            <span className="text-[11px] text-zinc-500">2024–2026 Guide Selection</span>
          </div>
          <div className="flex flex-col items-center">
            <Wine className="w-5 h-5 text-[#ff5a1f] mb-1.5" />
            <span className="text-white font-medium text-xs tracking-wider uppercase">Grand Sommelier Award</span>
            <span className="text-[11px] text-zinc-500">Wine Spectator Grand Award</span>
          </div>
          <div className="flex flex-col items-center">
            <Clock className="w-5 h-5 text-[#ff5a1f] mb-1.5" />
            <span className="text-white font-medium text-xs tracking-wider uppercase">Lunch & Dinner Tasting</span>
            <span className="text-[11px] text-zinc-500">Tuesday through Sunday</span>
          </div>
          <div className="flex flex-col items-center">
            <MapPin className="w-5 h-5 text-[#ff5a1f] mb-1.5" />
            <span className="text-white font-medium text-xs tracking-wider uppercase">Complimentary Valet</span>
            <span className="text-[11px] text-zinc-500">142 Regent Boulevard</span>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 grid grid-cols-1 md:grid-cols-4 gap-10">
        {/* Brand Column */}
        <div className="space-y-4">
          <div className="flex flex-col">
            <span className="text-3xl font-serif-luxury tracking-widest font-bold text-white flex items-center">
              kali
              <span className="w-1.5 h-1.5 rounded-full bg-[#ff5a1f] ml-1 mt-2 inline-block"></span>
            </span>
            <span className="text-[9px] uppercase tracking-[0.25em] text-zinc-500 font-medium">
              Haute Cuisine & Cocktails
            </span>
          </div>
          <p className="text-zinc-400 text-xs leading-relaxed">
            Where ancestral fire meets contemporary gastronomy. An intimate culinary atelier dedicated to pure ingredients, wood-fired nuances, and bespoke hospitality.
          </p>
          <div className="flex items-center gap-3 pt-2">
            <a href="#instagram" className="w-8 h-8 rounded-full bg-zinc-900 border border-white/10 flex items-center justify-center text-zinc-400 hover:text-white hover:border-[#ff5a1f] transition-colors">
              <Instagram className="w-4 h-4" />
            </a>
            <button
              onClick={onOpenSQLModal}
              title="Database Schema & Supabase Configuration"
              className="w-8 h-8 rounded-full bg-zinc-900 border border-white/10 flex items-center justify-center text-zinc-400 hover:text-[#ff5a1f] hover:border-[#ff5a1f] transition-colors"
            >
              <Database className="w-4 h-4" />
            </button>
            <button
              onClick={() => onSelectTab('admin')}
              title="Admin Portal"
              className="w-8 h-8 rounded-full bg-zinc-900 border border-white/10 flex items-center justify-center text-zinc-400 hover:text-white hover:border-[#ff5a1f] transition-colors"
            >
              <ShieldCheck className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Hours */}
        <div className="space-y-3">
          <h4 className="text-white font-serif-luxury text-base font-semibold tracking-wide uppercase">
            Service Hours
          </h4>
          <div className="space-y-2 text-xs text-zinc-400">
            <div>
              <p className="text-zinc-300 font-medium">Tuesday – Friday</p>
              <p>Lunch: 12:00 PM – 2:45 PM</p>
              <p>Dinner: 6:00 PM – 11:30 PM</p>
            </div>
            <div className="pt-2">
              <p className="text-zinc-300 font-medium">Saturday & Sunday</p>
              <p>Continuous Service: 1:00 PM – 11:45 PM</p>
            </div>
            <p className="text-[11px] text-zinc-500 pt-1 italic">Monday: Closed for culinary R&D</p>
          </div>
        </div>

        {/* Navigation */}
        <div className="space-y-3">
          <h4 className="text-white font-serif-luxury text-base font-semibold tracking-wide uppercase">
            Curated Access
          </h4>
          <ul className="space-y-2 text-xs">
            <li>
              <button onClick={() => onSelectTab('menu')} className="hover:text-[#ff5a1f] transition-colors">
                Seasonal Tasting Menu
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('book')} className="hover:text-[#ff5a1f] transition-colors">
                Reserve Table Seating
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('chef')} className="hover:text-[#ff5a1f] transition-colors">
                Chef Marco & Elena's Atelier
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('contact')} className="hover:text-[#ff5a1f] transition-colors">
                Private Dining & Location
              </button>
            </li>
            <li>
              <button onClick={() => onSelectTab('admin')} className="text-zinc-500 hover:text-zinc-300 transition-colors flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#ff5a1f]" />
                <span>Admin Login (/admin)</span>
              </button>
            </li>
          </ul>
        </div>

        {/* Contact Concierge */}
        <div className="space-y-3">
          <h4 className="text-white font-serif-luxury text-base font-semibold tracking-wide uppercase">
            Atelier Concierge
          </h4>
          <ul className="space-y-2.5 text-xs text-zinc-400">
            <li className="flex items-start gap-2">
              <MapPin className="w-4 h-4 text-[#ff5a1f] mt-0.5 flex-shrink-0" />
              <span>142 Regent Boulevard, Suite 500, Fine Arts District</span>
            </li>
            <li className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-[#ff5a1f] flex-shrink-0" />
              <span>+1 (555) 794-KALI (5254)</span>
            </li>
            <li className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-[#ff5a1f] flex-shrink-0" />
              <span>reservations@kali-restaurant.com</span>
            </li>
          </ul>
          <div className="pt-2">
            <span className="text-[11px] text-zinc-500 block">Dress Code: Smart Elegant</span>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/5 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-zinc-500">
          <p>© {new Date().getFullYear()} kali Restaurant & Bar Group. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <button onClick={onOpenSQLModal} className="hover:text-zinc-300 transition-colors">
              Supabase SQL Specification
            </button>
            <button onClick={() => onSelectTab('admin')} className="hover:text-[#ff5a1f] transition-colors">
              Staff Portal
            </button>
            <span>Terms of Dining</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
