import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { AuthenticatedUser, isUserAdmin } from '../services/db';
import { ShoppingBag, Menu as MenuIcon, X, Calendar, ShieldCheck, Database, User, LogOut, ShieldAlert } from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onOpenSQLModal: () => void;
  currentUser: AuthenticatedUser | null;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  onOpenSQLModal,
  currentUser,
  onLogout
}) => {
  const { totalCount, openCart } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isAdmin = isUserAdmin(currentUser);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'menu', label: 'Menu' },
    { id: 'book', label: 'Book a Table' },
    { id: 'chef', label: 'Chef & Story' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNav = (tabId: string) => {
    onSelectTab(tabId);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0a0a0a]/90 backdrop-blur-md border-b border-white/10 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Brand Logo */}
          <button
            onClick={() => handleNav('home')}
            className="flex items-center gap-2 group cursor-pointer text-left"
          >
            <div className="flex flex-col">
              <span className="text-3xl font-serif-luxury tracking-widest font-bold text-white group-hover:text-[#ff5a1f] transition-colors flex items-center">
                kali
                <span className="w-1.5 h-1.5 rounded-full bg-[#ff5a1f] ml-1 mt-2 inline-block"></span>
              </span>
              <span className="text-[9px] uppercase tracking-[0.25em] text-zinc-400 font-medium">
                Haute Cuisine & Bar
              </span>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`text-xs uppercase tracking-widest font-medium transition-colors cursor-pointer relative py-2 ${
                  currentTab === item.id
                    ? 'text-[#ff5a1f]'
                    : 'text-zinc-300 hover:text-white'
                }`}
              >
                {item.label}
                {currentTab === item.id && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#ff5a1f] rounded-full" />
                )}
              </button>
            ))}
          </nav>

          {/* Right Action Controls */}
          <div className="flex items-center space-x-3 sm:space-x-4">
            {/* Database SQL button */}
            <button
              onClick={onOpenSQLModal}
              title="View PostgreSQL / Supabase Schema"
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-zinc-900 border border-white/10 hover:border-white/20 text-xs text-zinc-400 hover:text-white transition-colors cursor-pointer"
            >
              <Database className="w-3.5 h-3.5 text-[#ff5a1f]" />
              <span className="text-[11px] font-mono">SQL / DB</span>
            </button>

            {/* Cart Trigger */}
            <button
              onClick={openCart}
              className="relative p-2.5 rounded-full bg-zinc-900/90 border border-white/10 hover:border-white/25 text-white transition-all cursor-pointer"
              aria-label="View Tasting Order"
            >
              <ShoppingBag className="w-4 h-4 text-zinc-200" />
              {totalCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#ff5a1f] text-white text-[10px] font-bold flex items-center justify-center animate-pulse">
                  {totalCount}
                </span>
              )}
            </button>

            {/* Reserve Table CTA */}
            <button
              onClick={() => handleNav('book')}
              className="hidden lg:flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-semibold tracking-wider uppercase transition-all shadow-lg shadow-[#ff5a1f]/20 cursor-pointer"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Reserve Table</span>
            </button>

            {/* Active User Status & Lock Site */}
            {currentUser && (
              <div className="flex items-center gap-1.5 bg-zinc-900 border border-white/10 rounded-full pl-3 pr-1.5 py-1">
                {isAdmin ? (
                  <button
                    onClick={() => handleNav('admin')}
                    className="flex items-center gap-1.5 text-xs text-white hover:text-[#ff5a1f] transition-colors cursor-pointer"
                    title="Super Administrator Portal"
                  >
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="font-semibold text-xs text-[#ff5a1f]">{currentUser.username}</span>
                    <span className="text-[9px] uppercase tracking-wider font-mono bg-[#ff5a1f]/20 text-[#ff5a1f] px-1.5 py-0.5 rounded">Admin</span>
                  </button>
                ) : (
                  <div
                    className="flex items-center gap-1.5 text-xs text-zinc-300 pr-1 select-none"
                    title={`Patron Account: @${currentUser.username} (${currentUser.role})`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-[#ff5a1f]" />
                    <span className="font-medium text-xs text-zinc-200">{currentUser.username}</span>
                    <span className="text-[9px] uppercase tracking-wider text-zinc-400 bg-white/5 border border-white/10 px-1 py-0.5 rounded">Patron</span>
                  </div>
                )}
                <button
                  onClick={onLogout}
                  className="p-1.5 text-zinc-400 hover:text-rose-400 rounded-full hover:bg-white/5 transition-colors cursor-pointer"
                  title="Lock Site & Sign Out"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Admin Portal Direct Icon - Strictly restricted to Admin */}
            {isAdmin && (
              <button
                onClick={() => handleNav('admin')}
                className={`p-2.5 rounded-full transition-colors cursor-pointer ${
                  currentTab === 'admin'
                    ? 'bg-[#ff5a1f] text-white shadow-lg shadow-[#ff5a1f]/30'
                    : 'bg-zinc-900/90 border border-[#ff5a1f]/40 text-[#ff5a1f] hover:text-white hover:bg-[#ff5a1f]/20'
                }`}
                title="Super Administrator Portal (/admin)"
              >
                <ShieldCheck className="w-4 h-4" />
              </button>
            )}

            {/* Mobile Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg bg-zinc-900 text-zinc-300 hover:text-white border border-white/10"
              aria-label="Toggle Navigation"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-white/10 bg-[#0c0c0c] px-4 pt-3 pb-6 space-y-3">
          <div className="space-y-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`w-full text-left px-3 py-2.5 text-xs uppercase tracking-wider font-medium rounded-lg transition-colors ${
                  currentTab === item.id
                    ? 'bg-[#ff5a1f]/15 text-[#ff5a1f] font-semibold'
                    : 'text-zinc-300 hover:bg-white/5'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-white/10 flex flex-col gap-2">
            <button
              onClick={() => {
                onOpenSQLModal();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-2 rounded-lg bg-zinc-900 border border-white/10 text-xs text-zinc-300"
            >
              <Database className="w-4 h-4 text-[#ff5a1f]" />
              <span>Database & Supabase Schema</span>
            </button>
            <button
              onClick={() => handleNav('book')}
              className="w-full py-2.5 rounded-lg bg-[#ff5a1f] text-white text-xs font-semibold uppercase tracking-wider text-center"
            >
              Book a Table
            </button>
            {currentUser && (
              <div className="flex items-center justify-between p-2.5 rounded-lg bg-zinc-900 border border-white/10 text-xs text-zinc-300">
                <span className="text-[#ff5a1f] font-semibold">Active: {currentUser.username}</span>
                <button onClick={onLogout} className="text-rose-400 text-xs font-medium flex items-center gap-1">
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Lock Site</span>
                </button>
              </div>
            )}
            {isAdmin && (
              <button
                onClick={() => handleNav('admin')}
                className="w-full py-2.5 rounded-lg bg-zinc-900 border border-[#ff5a1f]/30 text-[#ff5a1f] hover:text-white text-xs font-semibold text-center flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Super Admin Portal</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
