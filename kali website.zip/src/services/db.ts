import { MenuItem, Booking, AuditLog, User, SupabaseConfig, BookingStatus, UserRole, ActivityLog } from '../types';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Precomputed SHA-256 hashes
// sha256("admin123") = "240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa82280f1a7ca47dd"
export const ADMIN_PASSWORD_HASH = "240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa82280f1a7ca47dd";
// sha256("kali123") = "2ea533a2963707230fed1f5ab0d64afea356ee64ee018838e85650557a775c77"
export const KALI_PASSWORD_HASH = "2ea533a2963707230fed1f5ab0d64afea356ee64ee018838e85650557a775c77";

// Super Admin Identity
export const SUPER_ADMIN_EMAIL = "ktg17178@gmail.com";
export const SUPER_ADMIN_USERNAME = "ktg17178";

export interface AuthenticatedUser {
  id?: string;
  username: string;
  email?: string;
  role: 'admin' | 'staff' | 'vip_patron' | 'member';
  displayName: string;
}

/**
 * Authoritative check: Returns true ONLY if the user is an authorized administrator.
 * Grants super admin access exclusively to ktg17178@gmail.com and role 'admin'.
 */
export function isUserAdmin(user: AuthenticatedUser | User | null | undefined): boolean {
  if (!user) return false;
  const email = (user.email || '').toLowerCase().trim();
  const username = (user.username || '').toLowerCase().trim();
  if (email === SUPER_ADMIN_EMAIL || username === SUPER_ADMIN_USERNAME) return true;
  return user.role === 'admin';
}

export const VALID_USERS: Record<string, { hash: string; displayName: string; email: string; role: 'admin' }> = {
  kali: {
    hash: KALI_PASSWORD_HASH,
    displayName: 'Executive Chef & Owner Kali',
    email: 'marco.kali@kali-dining.com',
    role: 'admin'
  },
  admin: {
    hash: ADMIN_PASSWORD_HASH,
    displayName: 'System Administrator',
    email: 'concierge@kali-dining.com',
    role: 'admin'
  },
  ktg17178: {
    hash: ADMIN_PASSWORD_HASH,
    displayName: 'Super Administrator',
    email: 'ktg17178@gmail.com',
    role: 'admin'
  },
  'ktg17178@gmail.com': {
    hash: ADMIN_PASSWORD_HASH,
    displayName: 'Super Administrator',
    email: 'ktg17178@gmail.com',
    role: 'admin'
  }
};

export async function hashPassword(password: string): Promise<string> {
  const msgUint8 = new TextEncoder().encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// 12 Curated 5-Star Luxury Menu Items
export const SEED_MENU_ITEMS: MenuItem[] = [
  // VEG
  {
    id: 'menu-v1',
    name: 'Truffle Acquerello Risotto',
    description: 'Aged 7-year carnaroli rice, Perigord winter black truffles, 36-month Parmigiano Reggiano crisp, cultured herb butter.',
    price: 38,
    category: 'Veg',
    image_url: 'https://images.unsplash.com/photo-1633964913295-ceb43826e7c9?auto=format&fit=crop&w=800&q=80',
    is_special: true,
    calories: 520,
    prep_time: '25 min',
    allergens: ['Dairy']
  },
  {
    id: 'menu-v2',
    name: 'Charred Heirloom Beetroot Tartare',
    description: 'Slow-roasted salt-crust beetroots, smoked goat curd, candied Georgian walnuts, pickled mustard seed, micro sorrel.',
    price: 26,
    category: 'Veg',
    image_url: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80',
    is_special: false,
    calories: 340,
    prep_time: '18 min',
    allergens: ['Nuts', 'Dairy']
  },
  {
    id: 'menu-v3',
    name: 'Wild Morel & Sunchoke Velouté',
    description: 'Foraged French morels, caramelized sunchoke puree, roasted hazelnut brown butter, black garlic brioche wafer.',
    price: 29,
    category: 'Veg',
    image_url: 'https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=800&q=80',
    is_special: false,
    calories: 390,
    prep_time: '20 min',
    allergens: ['Gluten', 'Nuts']
  },

  // NON-VEG
  {
    id: 'menu-nv1',
    name: 'Miyazaki A5 Wagyu Tenderloin',
    description: 'Grade A5 Japanese Wagyu grilled over binchotan charcoal, bone marrow glaze, roasted king oyster mushroom, black garlic jus.',
    price: 95,
    category: 'Non-Veg',
    image_url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
    is_special: true,
    calories: 780,
    prep_time: '30 min',
    allergens: ['Soy']
  },
  {
    id: 'menu-nv2',
    name: 'Chilean Sea Bass Saikyo Miso',
    description: 'Sustainably caught glacier toothfish, 72-hour Kyoto white miso marinade, charred baby bok choy, dashi ginger reduction.',
    price: 54,
    category: 'Non-Veg',
    image_url: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=800&q=80',
    is_special: true,
    calories: 590,
    prep_time: '25 min',
    allergens: ['Fish', 'Soy']
  },
  {
    id: 'menu-nv3',
    name: 'Dry-Aged Duck Breast à l\'Orange',
    description: '21-day dry-aged Rohan duck breast, spiced heritage wildflower honey, caramelized endive, cassis reduction, parsnip silk.',
    price: 48,
    category: 'Non-Veg',
    image_url: 'https://images.unsplash.com/photo-1514944298352-7360098f98c8?auto=format&fit=crop&w=800&q=80',
    is_special: false,
    calories: 650,
    prep_time: '28 min',
    allergens: []
  },

  // DESSERTS
  {
    id: 'menu-d1',
    name: 'Valrhona Grand Cru Dark Sphere',
    description: '70% Guanaja chocolate dome, smoked salted caramel ganache, gold leaf flakes, poured table-side warm Tahitian vanilla bean cream.',
    price: 24,
    category: 'Desserts',
    image_url: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=800&q=80',
    is_special: true,
    calories: 460,
    prep_time: '15 min',
    allergens: ['Dairy', 'Gluten']
  },
  {
    id: 'menu-d2',
    name: 'Tahitian Vanilla Bean Mille-Feuille',
    description: 'Caramelized inverted puff pastry sheets, whipped Tahitian vanilla bean diplomat cream, passion fruit coulis.',
    price: 22,
    category: 'Desserts',
    image_url: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80',
    is_special: false,
    calories: 410,
    prep_time: '15 min',
    allergens: ['Gluten', 'Dairy', 'Eggs']
  },
  {
    id: 'menu-d3',
    name: 'Yuzu & Uji Matcha Garden',
    description: 'Ceremonial Uji matcha sponge cake, tart Japanese yuzu curd, roasted black sesame tuile, shiso sorbet.',
    price: 21,
    category: 'Desserts',
    image_url: 'https://images.unsplash.com/photo-1579954115545-a95591f28bfc?auto=format&fit=crop&w=800&q=80',
    is_special: false,
    calories: 360,
    prep_time: '15 min',
    allergens: ['Gluten', 'Dairy']
  },

  // DRINKS
  {
    id: 'menu-dr1',
    name: 'The Kali Obsidian Old Fashioned',
    description: 'WhistlePig 10-Yr Rye whiskey smoked with oak wood, smoked Madagascar vanilla reduction, Angostura & orange bitters, 24k gold leaf ice sphere.',
    price: 26,
    category: 'Drinks',
    image_url: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=800&q=80',
    is_special: true,
    calories: 190,
    prep_time: '8 min',
    allergens: []
  },
  {
    id: 'menu-dr2',
    name: 'Saffron & Blood Orange Botanist',
    description: 'Small-batch artisanal gin, clarified Sicilian blood orange, Kashmiri saffron infusion, sparkling yuzu water, thyme blossom.',
    price: 23,
    category: 'Drinks',
    image_url: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=800&q=80',
    is_special: false,
    calories: 175,
    prep_time: '6 min',
    allergens: []
  },
  {
    id: 'menu-dr3',
    name: 'Smoked Rosemary Zero-Proof Elixir',
    description: 'Non-alcoholic botanical spirit, charred rosemary smoke, fresh pink grapefruit cordial, agave, Himalayan pink salt rim.',
    price: 17,
    category: 'Drinks',
    image_url: 'https://images.unsplash.com/photo-1621263764928-df1444c5e859?auto=format&fit=crop&w=800&q=80',
    is_special: false,
    calories: 85,
    prep_time: '5 min',
    allergens: []
  }
];

export const INITIAL_BOOKINGS: Booking[] = [
  {
    id: 'KALI-9101',
    name: 'Lord Arthur Sterling',
    phone: '+1 (555) 234-5678',
    email: 'arthur.sterling@mayfair.co.uk',
    date: new Date().toISOString().split('T')[0], // Today
    time: '19:30',
    guests: 4,
    seating_preference: 'Chef\'s Counter',
    special_requests: 'Anniversary celebration. Prefer vintage Pinot Noir pairing.',
    status: 'confirmed',
    created_at: new Date(Date.now() - 3600000 * 5).toISOString()
  },
  {
    id: 'KALI-9102',
    name: 'Sophia Chen',
    phone: '+1 (555) 890-1234',
    email: 'sophia.chen@vanguard.io',
    date: new Date().toISOString().split('T')[0], // Today
    time: '20:00',
    guests: 2,
    seating_preference: 'Intimate Booth',
    special_requests: 'One guest has severe shellfish allergy.',
    status: 'pending',
    created_at: new Date(Date.now() - 3600000 * 2).toISOString()
  },
  {
    id: 'KALI-9103',
    name: 'Marcus Vance',
    phone: '+1 (555) 456-7890',
    email: 'marcus@vancecapital.com',
    date: new Date(Date.now() + 86400000).toISOString().split('T')[0], // Tomorrow
    time: '19:00',
    guests: 6,
    seating_preference: 'Main Dining Hall',
    special_requests: 'Corporate dining. Private sommelier requested.',
    status: 'confirmed',
    created_at: new Date(Date.now() - 3600000 * 18).toISOString()
  },
  {
    id: 'KALI-9104',
    name: 'Elena Rostova',
    phone: '+1 (555) 321-9876',
    email: 'elena.rostova@arts.org',
    date: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0], // Day after tomorrow
    time: '20:30',
    guests: 2,
    seating_preference: 'Garden Terrace',
    special_requests: 'Vegetarian tasting course requested.',
    status: 'pending',
    created_at: new Date(Date.now() - 3600000 * 1).toISOString()
  },
  {
    id: 'KALI-9105',
    name: 'Julian Holloway',
    phone: '+41 22 555 4321',
    email: 'julian@holloway-estate.ch',
    date: new Date().toISOString().split('T')[0], // Today
    time: '21:00',
    guests: 8,
    seating_preference: 'Chef\'s Counter',
    special_requests: 'Private cellar Burgundy tasting course with Wagyu.',
    status: 'confirmed',
    created_at: new Date(Date.now() - 3600000 * 8).toISOString()
  },
  {
    id: 'KALI-9106',
    name: 'Charlotte Beaumont',
    phone: '+33 1 44 55 66 77',
    email: 'charlotte@beaumont-luxury.fr',
    date: new Date(Date.now() - 86400000).toISOString().split('T')[0], // Yesterday
    time: '19:30',
    guests: 3,
    seating_preference: 'Intimate Booth',
    special_requests: 'Anniversary celebration completed.',
    status: 'completed',
    created_at: new Date(Date.now() - 3600000 * 26).toISOString()
  },
  {
    id: 'KALI-9107',
    name: 'Alexander Wright',
    phone: '+1 (555) 678-9012',
    email: 'alex.wright@venture.com',
    date: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
    time: '20:00',
    guests: 5,
    seating_preference: 'Main Dining Hall',
    special_requests: 'Client dinner, sommelier pairing requested.',
    status: 'confirmed',
    created_at: new Date(Date.now() - 3600000 * 10).toISOString()
  },
  {
    id: 'KALI-9108',
    name: 'Contessa Isabella Moretti',
    phone: '+39 02 555 7890',
    email: 'isabella.moretti@milano.it',
    date: new Date(Date.now() + 86400000 * 4).toISOString().split('T')[0],
    time: '20:30',
    guests: 2,
    seating_preference: 'Intimate Booth',
    special_requests: 'Table-side Valrhona sphere presentation.',
    status: 'pending',
    created_at: new Date(Date.now() - 3600000 * 3).toISOString()
  }
];

// Curated Mock Registered Users Database
export const INITIAL_USERS: User[] = [
  {
    id: 'USR-ADMIN-KTG',
    username: 'ktg17178',
    email: 'ktg17178@gmail.com',
    full_name: 'Administrator (KTG)',
    password_hash: ADMIN_PASSWORD_HASH,
    role: 'admin',
    phone: '+1 (555) 794-5250',
    registered_at: '2025-01-01T00:00:00.000Z'
  },
  {
    id: 'USR-1001',
    username: 'kali',
    email: 'marco.kali@kali-dining.com',
    full_name: 'Executive Chef Marco Kali',
    password_hash: KALI_PASSWORD_HASH,
    role: 'admin',
    phone: '+1 (555) 794-5254',
    registered_at: '2025-01-10T10:00:00.000Z'
  },
  {
    id: 'USR-1002',
    username: 'admin',
    email: 'concierge@kali-dining.com',
    full_name: 'Director of Operations',
    password_hash: ADMIN_PASSWORD_HASH,
    role: 'admin',
    phone: '+1 (555) 794-5255',
    registered_at: '2025-01-15T14:30:00.000Z'
  },
  {
    id: 'USR-1003',
    username: 'arthur_sterling',
    email: 'arthur.sterling@mayfair.co.uk',
    full_name: 'Lord Arthur Sterling',
    password_hash: ADMIN_PASSWORD_HASH,
    role: 'vip_patron',
    phone: '+1 (555) 234-5678',
    registered_at: '2025-03-22T18:15:00.000Z'
  },
  {
    id: 'USR-1004',
    username: 'sophia_chen',
    email: 'sophia.chen@vanguard.io',
    full_name: 'Sophia Chen',
    password_hash: ADMIN_PASSWORD_HASH,
    role: 'member',
    phone: '+1 (555) 890-1234',
    registered_at: '2025-05-18T11:45:00.000Z'
  },
  {
    id: 'USR-1005',
    username: 'marcus_vance',
    email: 'marcus@vancecapital.com',
    full_name: 'Marcus Vance',
    password_hash: ADMIN_PASSWORD_HASH,
    role: 'vip_patron',
    phone: '+1 (555) 456-7890',
    registered_at: '2025-06-04T09:20:00.000Z'
  },
  {
    id: 'USR-1006',
    username: 'elena_rostova',
    email: 'elena.rostova@arts.org',
    full_name: 'Elena Rostova',
    password_hash: ADMIN_PASSWORD_HASH,
    role: 'member',
    phone: '+1 (555) 321-9876',
    registered_at: '2025-07-12T16:50:00.000Z'
  },
  {
    id: 'USR-1007',
    username: 'julian_holloway',
    email: 'julian@holloway-estate.ch',
    full_name: 'Julian Holloway',
    password_hash: ADMIN_PASSWORD_HASH,
    role: 'vip_patron',
    phone: '+41 22 555 4321',
    registered_at: '2025-08-01T12:00:00.000Z'
  },
  {
    id: 'USR-1008',
    username: 'charlotte_beaumont',
    email: 'charlotte@beaumont-luxury.fr',
    full_name: 'Charlotte Beaumont',
    password_hash: ADMIN_PASSWORD_HASH,
    role: 'member',
    phone: '+33 1 44 55 66 77',
    registered_at: '2025-09-14T20:10:00.000Z'
  },
  {
    id: 'USR-1009',
    username: 'clara_fontaine',
    email: 'clara.fontaine@geneva-private.ch',
    full_name: 'Clara Fontaine',
    password_hash: ADMIN_PASSWORD_HASH,
    role: 'vip_patron',
    phone: '+41 22 789 0123',
    registered_at: '2025-10-02T14:20:00.000Z'
  },
  {
    id: 'USR-1010',
    username: 'david_kim',
    email: 'david.kim@seoul-tech.io',
    full_name: 'David Min-Jun Kim',
    password_hash: ADMIN_PASSWORD_HASH,
    role: 'member',
    phone: '+82 2 3456 7890',
    registered_at: '2025-11-19T08:45:00.000Z'
  },
  {
    id: 'USR-1011',
    username: 'olivia_rhodes',
    email: 'olivia.rhodes@manhattan.nyc',
    full_name: 'Olivia Rhodes',
    password_hash: ADMIN_PASSWORD_HASH,
    role: 'vip_patron',
    phone: '+1 (555) 678-4321',
    registered_at: '2025-12-05T17:30:00.000Z'
  },
  {
    id: 'USR-1012',
    username: 'lucas_muller',
    email: 'lucas.muller@zurich-art.ch',
    full_name: 'Lucas Müller',
    password_hash: ADMIN_PASSWORD_HASH,
    role: 'member',
    phone: '+41 44 123 4567',
    registered_at: '2026-01-08T11:15:00.000Z'
  }
];

export const INITIAL_LOGS: AuditLog[] = [
  {
    id: 'log-1',
    action: 'SYSTEM_BOOT',
    details: 'kali restaurant system initialized with 12 signature luxury dishes and security tables.',
    user: 'system',
    timestamp: new Date(Date.now() - 3600000 * 12).toISOString()
  },
  {
    id: 'log-2',
    action: 'ADMIN_LOGIN',
    details: 'Administrator authenticated successfully via secure SHA-256 session.',
    user: 'admin',
    timestamp: new Date(Date.now() - 3600000 * 6).toISOString()
  },
  {
    id: 'log-3',
    action: 'BOOKING_CONFIRMED',
    details: 'Booking KALI-9101 for Arthur Sterling (4 guests) confirmed.',
    user: 'admin',
    timestamp: new Date(Date.now() - 3600000 * 4).toISOString()
  }
];

export const INITIAL_ACTIVITY_LOGS: ActivityLog[] = [
  {
    id: 'act-101',
    ip_address: '192.168.1.102',
    page_url: '/',
    action: 'PAGE_VIEW: HOME',
    user_agent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
    created_at: new Date(Date.now() - 3600000 * 3.5).toISOString()
  },
  {
    id: 'act-102',
    ip_address: '192.168.1.102',
    page_url: '/menu',
    action: 'PAGE_VIEW: MENU',
    user_agent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
    created_at: new Date(Date.now() - 3600000 * 3.2).toISOString()
  },
  {
    id: 'act-103',
    ip_address: '192.168.1.102',
    page_url: '/menu',
    action: 'ADD_TO_CART: "Miyazaki A5 Wagyu Tenderloin" (Qty: 1, $95)',
    user_agent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
    created_at: new Date(Date.now() - 3600000 * 3.0).toISOString()
  },
  {
    id: 'act-104',
    ip_address: '192.168.1.102',
    page_url: '/book',
    action: 'BOOKING_SUBMITTED: Table for 4 guests by Lord Arthur Sterling (Today at 19:30)',
    user_agent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
    created_at: new Date(Date.now() - 3600000 * 2.8).toISOString()
  },
  {
    id: 'act-105',
    ip_address: '185.199.108.153',
    page_url: '/login',
    action: 'LOGIN_SUCCESS: User "kali" authenticated',
    user_agent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0',
    created_at: new Date(Date.now() - 3600000 * 1.5).toISOString()
  },
  {
    id: 'act-106',
    ip_address: '185.199.108.153',
    page_url: '/admin',
    action: 'PAGE_VIEW: ADMIN',
    user_agent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0',
    created_at: new Date(Date.now() - 3600000 * 1.4).toISOString()
  }
];

// LocalStorage Keys
const STORAGE_KEYS = {
  MENU: 'kali_menu_items_v2',
  BOOKINGS: 'kali_bookings_v2',
  USERS: 'kali_users_v3',
  LOGS: 'kali_audit_logs_v2',
  ACTIVITY_LOGS: 'kali_activity_logs_v1',
  SUPABASE_CONFIG: 'kali_supabase_config_v2',
  ADMIN_SESSION: 'kali_site_gate_session_v3'
};

class KaliDatabaseService {
  private supabase: SupabaseClient | null = null;
  private config: SupabaseConfig = {
    url: '',
    anonKey: '',
    isConnected: false
  };

  constructor() {
    this.initStorage();
    this.loadSupabaseConfig();
  }

  private initStorage() {
    if (typeof window === 'undefined') return;

    if (!localStorage.getItem(STORAGE_KEYS.MENU)) {
      localStorage.setItem(STORAGE_KEYS.MENU, JSON.stringify(SEED_MENU_ITEMS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.BOOKINGS)) {
      localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(INITIAL_BOOKINGS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
    } else {
      // Ensure Super Admin (ktg17178@gmail.com) is always present even if users were previously cached
      try {
        const existing = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
        if (Array.isArray(existing) && !existing.some((u: User) => (u.email || '').toLowerCase() === SUPER_ADMIN_EMAIL || (u.username || '').toLowerCase() === SUPER_ADMIN_USERNAME)) {
          const superAdminUser = INITIAL_USERS[0];
          localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify([superAdminUser, ...existing]));
        }
      } catch {
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
      }
    }
    if (!localStorage.getItem(STORAGE_KEYS.LOGS)) {
      localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(INITIAL_LOGS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.ACTIVITY_LOGS)) {
      localStorage.setItem(STORAGE_KEYS.ACTIVITY_LOGS, JSON.stringify(INITIAL_ACTIVITY_LOGS));
    }
  }

  private loadSupabaseConfig() {
    if (typeof window === 'undefined') return;
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SUPABASE_CONFIG);
      if (saved) {
        this.config = JSON.parse(saved);
        if (this.config.url && this.config.anonKey) {
          this.supabase = createClient(this.config.url, this.config.anonKey);
        }
      }
    } catch {
      // fallback
    }
  }

  // --- SUPABASE CONFIGURATION ---
  public getSupabaseConfig(): SupabaseConfig {
    return { ...this.config };
  }

  public async configureSupabase(url: string, anonKey: string): Promise<{ success: boolean; message: string }> {
    try {
      if (!url.trim() || !anonKey.trim()) {
        this.supabase = null;
        this.config = { url: '', anonKey: '', isConnected: false };
        localStorage.removeItem(STORAGE_KEYS.SUPABASE_CONFIG);
        this.addLog('CONFIG_UPDATE', 'Supabase disconnected. Using local database mode.', 'admin');
        return { success: true, message: 'Switched to local database mode.' };
      }

      const client = createClient(url.trim(), anonKey.trim());
      // Test connectivity by querying menu_items or auth
      const { error } = await client.from('menu_items').select('count', { count: 'exact', head: true });

      if (error && error.code !== 'PGRST116') {
        // Even if table doesn't exist yet, client connection test could yield table not found
        console.warn('Supabase test ping message:', error.message);
      }

      this.supabase = client;
      this.config = {
        url: url.trim(),
        anonKey: anonKey.trim(),
        isConnected: true,
        lastTested: new Date().toISOString()
      };
      localStorage.setItem(STORAGE_KEYS.SUPABASE_CONFIG, JSON.stringify(this.config));
      this.addLog('SUPABASE_CONNECTED', `Connected to Supabase project: ${url.slice(0, 24)}...`, 'admin');
      return { success: true, message: 'Successfully connected to Supabase database!' };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to connect to Supabase';
      return { success: false, message: msg };
    }
  }

  // --- MENU ITEMS ---
  public async getMenuItems(): Promise<MenuItem[]> {
    // If Supabase is connected, try to fetch from it
    if (this.supabase && this.config.isConnected) {
      try {
        const { data, error } = await this.supabase
          .from('menu_items')
          .select('*')
          .order('name');
        if (!error && data && data.length > 0) {
          return data as MenuItem[];
        }
      } catch (err) {
        console.warn('Supabase fetch failed, falling back to local storage', err);
      }
    }

    // Local fallback
    try {
      const items = localStorage.getItem(STORAGE_KEYS.MENU);
      return items ? JSON.parse(items) : SEED_MENU_ITEMS;
    } catch {
      return SEED_MENU_ITEMS;
    }
  }

  public async addMenuItem(item: Omit<MenuItem, 'id'>): Promise<MenuItem> {
    const newItem: MenuItem = {
      ...item,
      id: `menu-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`
    };

    // If Supabase is active
    if (this.supabase && this.config.isConnected) {
      try {
        await this.supabase.from('menu_items').insert([newItem]);
      } catch (err) {
        console.warn('Supabase insert failed', err);
      }
    }

    // Always keep local updated
    const current = await this.getMenuItems();
    const updated = [newItem, ...current];
    localStorage.setItem(STORAGE_KEYS.MENU, JSON.stringify(updated));

    this.addLog('MENU_CREATE', `Added dish: "${newItem.name}" (${newItem.category}, $${newItem.price})`, 'admin');
    return newItem;
  }

  public async updateMenuItem(item: MenuItem): Promise<MenuItem> {
    if (this.supabase && this.config.isConnected) {
      try {
        await this.supabase.from('menu_items').update(item).eq('id', item.id);
      } catch (err) {
        console.warn('Supabase update failed', err);
      }
    }

    const current = await this.getMenuItems();
    const updated = current.map(i => i.id === item.id ? item : i);
    localStorage.setItem(STORAGE_KEYS.MENU, JSON.stringify(updated));

    this.addLog('MENU_UPDATE', `Modified dish: "${item.name}"`, 'admin');
    return item;
  }

  public async deleteMenuItem(id: string): Promise<boolean> {
    const current = await this.getMenuItems();
    const target = current.find(i => i.id === id);

    if (this.supabase && this.config.isConnected) {
      try {
        await this.supabase.from('menu_items').delete().eq('id', id);
      } catch (err) {
        console.warn('Supabase delete failed', err);
      }
    }

    const updated = current.filter(i => i.id !== id);
    localStorage.setItem(STORAGE_KEYS.MENU, JSON.stringify(updated));

    if (target) {
      this.addLog('MENU_DELETE', `Deleted dish: "${target.name}"`, 'admin');
    }
    return true;
  }

  public async resetMenuToDefaults(): Promise<MenuItem[]> {
    localStorage.setItem(STORAGE_KEYS.MENU, JSON.stringify(SEED_MENU_ITEMS));
    this.addLog('MENU_RESET', 'Menu items reset to 12 curated 5-star defaults.', 'admin');
    return SEED_MENU_ITEMS;
  }

  // --- BOOKINGS ---
  public async getBookings(): Promise<Booking[]> {
    if (this.supabase && this.config.isConnected) {
      try {
        const { data, error } = await this.supabase
          .from('bookings')
          .select('*')
          .order('created_at', { ascending: false });
        if (!error && data) {
          return data as Booking[];
        }
      } catch (err) {
        console.warn('Supabase bookings fetch failed', err);
      }
    }

    try {
      const data = localStorage.getItem(STORAGE_KEYS.BOOKINGS);
      return data ? JSON.parse(data) : INITIAL_BOOKINGS;
    } catch {
      return INITIAL_BOOKINGS;
    }
  }

  public async createBooking(
    bookingData: Omit<Booking, 'id' | 'status' | 'created_at'>
  ): Promise<Booking> {
    const randomCode = Math.floor(1000 + Math.random() * 9000);
    const newBooking: Booking = {
      ...bookingData,
      id: `KALI-${randomCode}`,
      status: 'pending',
      created_at: new Date().toISOString()
    };

    if (this.supabase && this.config.isConnected) {
      try {
        await this.supabase.from('bookings').insert([newBooking]);
      } catch (err) {
        console.warn('Supabase booking insert failed', err);
      }
    }

    const current = await this.getBookings();
    const updated = [newBooking, ...current];
    localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(updated));

    this.addLog(
      'BOOKING_NEW',
      `New reservation request ${newBooking.id} for ${newBooking.name} (${newBooking.guests} guests on ${newBooking.date} at ${newBooking.time})`,
      'guest'
    );
    return newBooking;
  }

  public async updateBookingStatus(id: string, status: BookingStatus): Promise<boolean> {
    if (this.supabase && this.config.isConnected) {
      try {
        await this.supabase.from('bookings').update({ status }).eq('id', id);
      } catch (err) {
        console.warn('Supabase booking status update failed', err);
      }
    }

    const current = await this.getBookings();
    const updated = current.map(b => b.id === id ? { ...b, status } : b);
    localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(updated));

    const item = current.find(b => b.id === id);
    const guestInfo = item ? `for ${item.name}` : '';
    this.addLog('BOOKING_STATUS_CHANGE', `Booking ${id} ${guestInfo} marked as ${status.toUpperCase()}`, 'admin');
    return true;
  }

  public async deleteBooking(id: string): Promise<boolean> {
    if (this.supabase && this.config.isConnected) {
      try {
        await this.supabase.from('bookings').delete().eq('id', id);
      } catch (err) {
        console.warn('Supabase booking delete failed', err);
      }
    }

    const current = await this.getBookings();
    const updated = current.filter(b => b.id !== id);
    localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(updated));

    this.addLog('BOOKING_DELETE', `Deleted booking record ${id}`, 'admin');
    return true;
  }

  // --- AUDIT LOGS ---
  public getLogs(): AuditLog[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.LOGS);
      return data ? JSON.parse(data) : INITIAL_LOGS;
    } catch {
      return INITIAL_LOGS;
    }
  }

  public addLog(action: string, details: string, user: string = 'admin'): void {
    const newLog: AuditLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      action,
      details,
      user,
      timestamp: new Date().toISOString()
    };
    try {
      const current = this.getLogs();
      const updated = [newLog, ...current].slice(0, 100); // keep last 100 logs
      localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(updated));
    } catch {
      // ignore
    }
  }

  public clearLogs(): void {
    const resetLog: AuditLog = {
      id: `log-${Date.now()}`,
      action: 'LOGS_CLEARED',
      details: 'Admin audit logs history reset.',
      user: 'admin',
      timestamp: new Date().toISOString()
    };
    localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify([resetLog]));
  }

  // --- ACTIVITY LOGS (id, ip_address, page_url, action, user_agent, created_at) ---
  public async getActivityLogs(): Promise<ActivityLog[]> {
    if (this.supabase && this.config.isConnected) {
      try {
        const { data, error } = await this.supabase
          .from('activity_logs')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(200);
        if (!error && data && data.length > 0) {
          return data as ActivityLog[];
        }
      } catch (err) {
        console.warn('Supabase activity_logs fetch failed, falling back to local storage', err);
      }
    }

    try {
      const data = localStorage.getItem(STORAGE_KEYS.ACTIVITY_LOGS);
      return data ? JSON.parse(data) : INITIAL_ACTIVITY_LOGS;
    } catch {
      return INITIAL_ACTIVITY_LOGS;
    }
  }

  public async addActivityLog(log: ActivityLog): Promise<void> {
    if (this.supabase && this.config.isConnected) {
      try {
        await this.supabase.from('activity_logs').insert([log]);
      } catch (err) {
        console.warn('Supabase activity_logs insert failed', err);
      }
    }

    try {
      const current = await this.getActivityLogs();
      const updated = [log, ...current.filter(l => l.id !== log.id)].slice(0, 250);
      localStorage.setItem(STORAGE_KEYS.ACTIVITY_LOGS, JSON.stringify(updated));
    } catch {
      // ignore
    }
  }

  public async clearActivityLogs(): Promise<void> {
    if (this.supabase && this.config.isConnected) {
      try {
        await this.supabase.from('activity_logs').delete().neq('id', '');
      } catch (err) {
        console.warn('Supabase activity_logs clear failed', err);
      }
    }
    localStorage.setItem(STORAGE_KEYS.ACTIVITY_LOGS, JSON.stringify([]));
  }

  // --- USERS & REGISTRATIONS ---
  public async getUsers(): Promise<User[]> {
    let list: User[] = [];
    if (this.supabase && this.config.isConnected) {
      try {
        const { data, error } = await this.supabase
          .from('users')
          .select('*')
          .order('registered_at', { ascending: false });
        if (!error && data && data.length > 0) {
          list = data as User[];
        }
      } catch (err) {
        console.warn('Supabase users fetch failed, fallback to local', err);
      }
    }

    if (list.length === 0) {
      try {
        const data = localStorage.getItem(STORAGE_KEYS.USERS);
        list = data ? JSON.parse(data) : INITIAL_USERS;
      } catch {
        list = INITIAL_USERS;
      }
    }

    // Always ensure Super Admin (ktg17178@gmail.com) is present in users list
    if (!list.some(u => (u.email || '').toLowerCase() === SUPER_ADMIN_EMAIL || (u.username || '').toLowerCase() === SUPER_ADMIN_USERNAME)) {
      list = [INITIAL_USERS[0], ...list];
    }
    return list;
  }

  public async addUser(userData: Omit<User, 'id' | 'registered_at'>): Promise<User> {
    const newUser: User = {
      ...userData,
      id: `USR-${Math.floor(1000 + Math.random() * 9000)}`,
      registered_at: new Date().toISOString()
    };

    if (this.supabase && this.config.isConnected) {
      try {
        await this.supabase.from('users').insert([newUser]);
      } catch (err) {
        console.warn('Supabase user insert failed', err);
      }
    }

    const current = await this.getUsers();
    const updated = [newUser, ...current];
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(updated));

    this.addLog('USER_REGISTERED', `New account created: "${newUser.username}" (${newUser.email}, Role: ${newUser.role})`, 'admin');
    return newUser;
  }

  public async deleteUser(id: string): Promise<boolean> {
    const current = await this.getUsers();
    const target = current.find(u => u.id === id);

    if (this.supabase && this.config.isConnected) {
      try {
        await this.supabase.from('users').delete().eq('id', id);
      } catch (err) {
        console.warn('Supabase user delete failed', err);
      }
    }

    const updated = current.filter(u => u.id !== id);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(updated));

    if (target) {
      this.addLog('USER_DELETED', `Deleted user account "${target.username}" (${target.email})`, 'admin');
    }
    return true;
  }

  public async resetUsers(): Promise<User[]> {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
    this.addLog('USERS_RESET', 'Users database reset to initial mock registered users.', 'admin');
    return INITIAL_USERS;
  }

  // --- REGISTRATION ---
  public async registerUser(data: {
    full_name: string;
    username: string;
    email: string;
    passwordPlain: string;
    phone?: string;
    role?: UserRole;
  }): Promise<{ success: boolean; user?: User; authUser?: AuthenticatedUser; error?: string }> {
    const cleanUser = data.username.trim().toLowerCase().replace(/[^a-z0-9_]/g, '_');
    const cleanEmail = data.email.trim().toLowerCase();
    const cleanPass = data.passwordPlain.trim();
    const fullName = data.full_name.trim();

    if (!fullName) {
      return { success: false, error: 'Full name is required.' };
    }
    if (!cleanUser || cleanUser.length < 3) {
      return { success: false, error: 'Username must be at least 3 characters (letters, numbers, underscores).' };
    }
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      return { success: false, error: 'Please enter a valid electronic mail address.' };
    }
    if (!cleanPass || cleanPass.length < 4) {
      return { success: false, error: 'Password must be at least 4 characters.' };
    }

    const currentUsers = await this.getUsers();
    if (currentUsers.some(u => u.username.toLowerCase() === cleanUser) || cleanUser === 'kali' || cleanUser === 'admin') {
      return { success: false, error: `Username "@${cleanUser}" is already registered. Please choose another.` };
    }
    if (currentUsers.some(u => u.email.toLowerCase() === cleanEmail)) {
      return { success: false, error: `Electronic mail "${cleanEmail}" is already registered. Please sign in.` };
    }

    const isSuperAdmin = cleanEmail === SUPER_ADMIN_EMAIL || cleanUser === SUPER_ADMIN_USERNAME;
    const assignedRole: UserRole = isSuperAdmin ? 'admin' : (data.role && data.role !== 'admin' ? data.role : 'member');

    const password_hash = await hashPassword(cleanPass);
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const newId = isSuperAdmin ? 'USR-ADMIN-KTG' : `PATRON-${randomNum}`;

    const newUser: User = {
      id: newId,
      username: cleanUser,
      email: cleanEmail,
      full_name: fullName,
      password_hash,
      role: assignedRole,
      phone: data.phone?.trim() || undefined,
      registered_at: new Date().toISOString()
    };

    if (this.supabase && this.config.isConnected) {
      try {
        await this.supabase.from('users').insert([newUser]);
      } catch (err) {
        console.warn('Supabase user insert failed', err);
      }
    }

    const updated = [newUser, ...currentUsers];
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(updated));

    this.addLog('PATRON_REGISTERED', `New account registration: ${newUser.full_name} (@${newUser.username}, ${newUser.email}) - Role: ${newUser.role}`, newUser.username);

    const authUser: AuthenticatedUser = {
      id: newUser.id,
      username: newUser.username,
      email: newUser.email,
      role: newUser.role,
      displayName: newUser.full_name
    };

    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.ADMIN_SESSION, JSON.stringify(authUser));
    }

    return { success: true, user: newUser, authUser };
  }

  // --- AUTHENTICATION ---
  public async authenticateUser(username: string, passwordPlain: string): Promise<{ success: boolean; user?: AuthenticatedUser; error?: string }> {
    const cleanUser = username.trim().toLowerCase();
    const cleanPass = passwordPlain.trim();

    // 1. Check known master credentials (kali / admin / ktg17178)
    const expectedMaster = VALID_USERS[cleanUser];
    if (expectedMaster) {
      const hashed = await hashPassword(cleanPass);
      if (hashed === expectedMaster.hash || cleanPass === 'admin123' || cleanPass === 'kali123') {
        const authUser: AuthenticatedUser = {
          id: cleanUser === 'kali' ? 'USR-1001' : (cleanUser.includes('ktg') ? 'USR-ADMIN-KTG' : 'USR-1002'),
          username: cleanUser.includes('@') ? 'ktg17178' : cleanUser,
          email: expectedMaster.email,
          role: 'admin',
          displayName: expectedMaster.displayName
        };
        if (typeof window !== 'undefined') {
          localStorage.setItem(STORAGE_KEYS.ADMIN_SESSION, JSON.stringify(authUser));
        }
        this.addLog('LOGIN_SUCCESS', `Master user "${cleanUser}" (${expectedMaster.displayName}) authenticated successfully.`, cleanUser);
        return { success: true, user: authUser };
      }
    }

    // 2. Check registered user database (by username or email)
    const registeredUsers = await this.getUsers();
    const matchingUser = registeredUsers.find(
      u => u.username.toLowerCase() === cleanUser || u.email.toLowerCase() === cleanUser
    );

    if (matchingUser) {
      const hashed = await hashPassword(cleanPass);
      const isUserAdminRole = isUserAdmin(matchingUser);

      // Admin accounts can use their hash or fallback master pass; normal patrons strictly require their hashed password
      const passwordMatches = hashed === matchingUser.password_hash || (isUserAdminRole && (cleanPass === 'admin123' || cleanPass === 'kali123'));

      if (passwordMatches) {
        const authUser: AuthenticatedUser = {
          id: matchingUser.id,
          username: matchingUser.username,
          email: matchingUser.email,
          role: isUserAdminRole ? 'admin' : matchingUser.role,
          displayName: matchingUser.full_name
        };
        if (typeof window !== 'undefined') {
          localStorage.setItem(STORAGE_KEYS.ADMIN_SESSION, JSON.stringify(authUser));
        }
        this.addLog('LOGIN_SUCCESS', `Account "${matchingUser.username}" (${matchingUser.email}) logged in with role: ${authUser.role}.`, matchingUser.username);
        return { success: true, user: authUser };
      }
    }

    return { success: false, error: 'Invalid username or password. Access denied.' };
  }

  public getCurrentUser(): AuthenticatedUser | null {
    if (typeof window === 'undefined') return null;
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ADMIN_SESSION);
      if (!data) return null;
      if (data === 'authenticated') {
        return { username: 'admin', role: 'admin', displayName: 'System Administrator' };
      }
      return JSON.parse(data);
    } catch {
      return null;
    }
  }

  public logoutUser(): void {
    if (typeof window !== 'undefined') {
      const user = this.getCurrentUser();
      localStorage.removeItem(STORAGE_KEYS.ADMIN_SESSION);
      if (user) {
        this.addLog('LOGOUT', `User "${user.username}" signed out.`, user.username);
      }
    }
  }

  // --- SQL SCHEMA EXPORT ---
  public getSQLSchema(): string {
    return `-- =========================================================
-- kali Luxury Restaurant - Complete Supabase / PostgreSQL Schema
-- =========================================================

-- 1. Create menu_items table
CREATE TABLE IF NOT EXISTS public.menu_items (
    id TEXT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    price NUMERIC(10, 2) NOT NULL CHECK (price >= 0),
    category VARCHAR(50) NOT NULL CHECK (category IN ('Veg', 'Non-Veg', 'Desserts', 'Drinks')),
    image_url TEXT NOT NULL,
    is_special BOOLEAN DEFAULT FALSE,
    calories INTEGER,
    prep_time VARCHAR(50),
    allergens TEXT[] DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. Create bookings & registrations table
CREATE TABLE IF NOT EXISTS public.bookings (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    email VARCHAR(255) NOT NULL,
    date DATE NOT NULL,
    time VARCHAR(50) NOT NULL,
    guests INTEGER NOT NULL CHECK (guests > 0),
    seating_preference VARCHAR(100),
    special_requests TEXT,
    status VARCHAR(50) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'rejected', 'completed')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. Create users & member accounts table
CREATE TABLE IF NOT EXISTS public.users (
    id VARCHAR(50) PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'member' NOT NULL,
    phone VARCHAR(50),
    registered_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. Create activity_logs table (Activity Log System)
CREATE TABLE IF NOT EXISTS public.activity_logs (
    id TEXT PRIMARY KEY,
    ip_address VARCHAR(100) NOT NULL,
    page_url TEXT NOT NULL,
    action TEXT NOT NULL,
    user_agent TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 5. Enable Row Level Security (RLS)
ALTER TABLE public.menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;

-- 6. Create Public & Admin Access Policies
CREATE POLICY "Public menu read access" 
ON public.menu_items FOR SELECT USING (true);

CREATE POLICY "Public booking insertion" 
ON public.bookings FOR INSERT WITH CHECK (true);

CREATE POLICY "Public activity log insertion" 
ON public.activity_logs FOR INSERT WITH CHECK (true);

CREATE POLICY "Admin full menu access" 
ON public.menu_items FOR ALL USING (true);

CREATE POLICY "Admin full booking access" 
ON public.bookings FOR ALL USING (true);

CREATE POLICY "Admin full user access" 
ON public.users FOR ALL USING (true);

CREATE POLICY "Admin full activity log access" 
ON public.activity_logs FOR ALL USING (true);

-- 6. Seed Registered Users Database (Mock Users with Usernames & Emails)
INSERT INTO public.users (id, username, email, full_name, password_hash, role, phone, registered_at)
VALUES
('USR-ADMIN-KTG', 'ktg17178', 'ktg17178@gmail.com', 'Super Administrator (KTG)', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa82280f1a7ca47dd', 'admin', '+1 (555) 794-5250', '2025-01-01 00:00:00+00'),
('USR-1001', 'kali', 'marco.kali@kali-dining.com', 'Executive Chef Marco Kali', '2ea533a2963707230fed1f5ab0d64afea356ee64ee018838e85650557a775c77', 'admin', '+1 (555) 794-5254', '2025-01-10 10:00:00+00'),
('USR-1002', 'admin', 'concierge@kali-dining.com', 'Director of Operations', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa82280f1a7ca47dd', 'admin', '+1 (555) 794-5255', '2025-01-15 14:30:00+00'),
('USR-1003', 'arthur_sterling', 'arthur.sterling@mayfair.co.uk', 'Lord Arthur Sterling', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa82280f1a7ca47dd', 'vip_patron', '+1 (555) 234-5678', '2025-03-22 18:15:00+00'),
('USR-1004', 'sophia_chen', 'sophia.chen@vanguard.io', 'Sophia Chen', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa82280f1a7ca47dd', 'member', '+1 (555) 890-1234', '2025-05-18 11:45:00+00'),
('USR-1005', 'marcus_vance', 'marcus@vancecapital.com', 'Marcus Vance', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa82280f1a7ca47dd', 'vip_patron', '+1 (555) 456-7890', '2025-06-04 09:20:00+00'),
('USR-1006', 'elena_rostova', 'elena.rostova@arts.org', 'Elena Rostova', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa82280f1a7ca47dd', 'member', '+1 (555) 321-9876', '2025-07-12 16:50:00+00'),
('USR-1007', 'julian_holloway', 'julian@holloway-estate.ch', 'Julian Holloway', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa82280f1a7ca47dd', 'vip_patron', '+41 22 555 4321', '2025-08-01 12:00:00+00'),
('USR-1008', 'charlotte_beaumont', 'charlotte@beaumont-luxury.fr', 'Charlotte Beaumont', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa82280f1a7ca47dd', 'member', '+33 1 44 55 66 77', '2025-09-14 20:10:00+00'),
('USR-1009', 'clara_fontaine', 'clara.fontaine@geneva-private.ch', 'Clara Fontaine', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa82280f1a7ca47dd', 'vip_patron', '+41 22 789 0123', '2025-10-02 14:20:00+00'),
('USR-1010', 'david_kim', 'david.kim@seoul-tech.io', 'David Min-Jun Kim', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa82280f1a7ca47dd', 'member', '+82 2 3456 7890', '2025-11-19 08:45:00+00'),
('USR-1011', 'olivia_rhodes', 'olivia.rhodes@manhattan.nyc', 'Olivia Rhodes', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa82280f1a7ca47dd', 'vip_patron', '+1 (555) 678-4321', '2025-12-05 17:30:00+00'),
('USR-1012', 'lucas_muller', 'lucas.muller@zurich-art.ch', 'Lucas Müller', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa82280f1a7ca47dd', 'member', '+41 44 123 4567', '2026-01-08 11:15:00+00')
ON CONFLICT (username) DO NOTHING;

-- 7. Seed 12 Luxury Signature Menu Items
INSERT INTO public.menu_items (id, name, description, price, category, image_url, is_special)
VALUES
('menu-v1', 'Truffle Acquerello Risotto', 'Aged 7-year carnaroli rice, Perigord winter black truffles, 36-month Parmigiano Reggiano crisp.', 38, 'Veg', 'https://images.unsplash.com/photo-1633964913295-ceb43826e7c9?auto=format&fit=crop&w=800&q=80', true),
('menu-v2', 'Charred Heirloom Beetroot Tartare', 'Slow-roasted salt-crust beetroots, smoked goat curd, candied Georgian walnuts, micro sorrel.', 26, 'Veg', 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80', false),
('menu-v3', 'Wild Morel & Sunchoke Velouté', 'Foraged French morels, caramelized sunchoke puree, roasted hazelnut brown butter.', 29, 'Veg', 'https://images.unsplash.com/photo-1547592166-23ac45744acd?auto=format&fit=crop&w=800&q=80', false),
('menu-nv1', 'Miyazaki A5 Wagyu Tenderloin', 'Grade A5 Japanese Wagyu grilled over binchotan charcoal, bone marrow glaze, black garlic jus.', 95, 'Non-Veg', 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80', true),
('menu-nv2', 'Chilean Sea Bass Saikyo Miso', 'Sustainably caught glacier toothfish, 72-hour Kyoto white miso marinade, charred bok choy.', 54, 'Non-Veg', 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=800&q=80', true),
('menu-nv3', 'Dry-Aged Duck Breast à l''Orange', '21-day dry-aged Rohan duck breast, spiced wildflower honey, caramelized endive, cassis reduction.', 48, 'Non-Veg', 'https://images.unsplash.com/photo-1514944298352-7360098f98c8?auto=format&fit=crop&w=800&q=80', false),
('menu-d1', 'Valrhona Grand Cru Dark Sphere', '70% Guanaja chocolate dome, smoked salted caramel ganache, warm Tahitian vanilla bean pour.', 24, 'Desserts', 'https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=800&q=80', true),
('menu-d2', 'Tahitian Vanilla Bean Mille-Feuille', 'Caramelized inverted puff pastry, whipped Tahitian vanilla diplomat cream, passion fruit coulis.', 22, 'Desserts', 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80', false),
('menu-d3', 'Yuzu & Uji Matcha Garden', 'Ceremonial Uji matcha sponge, tart Japanese yuzu curd, roasted black sesame tuile, shiso sorbet.', 21, 'Desserts', 'https://images.unsplash.com/photo-1579954115545-a95591f28bfc?auto=format&fit=crop&w=800&q=80', false),
('menu-dr1', 'The Kali Obsidian Old Fashioned', 'WhistlePig 10-Yr Rye smoked with oak, smoked vanilla bean reduction, 24k gold leaf ice sphere.', 26, 'Drinks', 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=800&q=80', true),
('menu-dr2', 'Saffron & Blood Orange Botanist', 'Artisanal gin, clarified Sicilian blood orange, Kashmiri saffron tincture, sparkling yuzu.', 23, 'Drinks', 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=800&q=80', false),
('menu-dr3', 'Smoked Rosemary Zero-Proof Elixir', 'Non-alcoholic botanical spirit, charred rosemary smoke, pink grapefruit cordial, Himalayan salt.', 17, 'Drinks', 'https://images.unsplash.com/photo-1621263764928-df1444c5e859?auto=format&fit=crop&w=800&q=80', false)
ON CONFLICT (id) DO NOTHING;

-- 8. Seed Initial Activity Logs
INSERT INTO public.activity_logs (id, ip_address, page_url, action, user_agent, created_at)
VALUES
('act-101', '192.168.1.102', '/', 'PAGE_VIEW: HOME', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', timezone('utc'::text, now()) - interval '3 hours'),
('act-102', '192.168.1.102', '/menu', 'PAGE_VIEW: MENU', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', timezone('utc'::text, now()) - interval '2 hours 45 minutes'),
('act-103', '192.168.1.102', '/menu', 'ADD_TO_CART: "Miyazaki A5 Wagyu Tenderloin" (Qty: 1, $95)', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', timezone('utc'::text, now()) - interval '2 hours 30 minutes'),
('act-104', '192.168.1.102', '/book', 'BOOKING_SUBMITTED: Table for 4 guests by Lord Arthur Sterling', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36', timezone('utc'::text, now()) - interval '2 hours'),
('act-105', '185.199.108.153', '/login', 'LOGIN_SUCCESS: User "kali" authenticated', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0', timezone('utc'::text, now()) - interval '1 hour'),
('act-106', '185.199.108.153', '/admin', 'PAGE_VIEW: ADMIN', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0', timezone('utc'::text, now()) - interval '50 minutes')
ON CONFLICT (id) DO NOTHING;
`;
  }
}

export const dbService = new KaliDatabaseService();
