export type MenuCategory = 'Veg' | 'Non-Veg' | 'Desserts' | 'Drinks';

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: MenuCategory;
  image_url: string;
  is_special: boolean;
  calories?: number;
  prep_time?: string;
  allergens?: string[];
}

export type BookingStatus = 'pending' | 'confirmed' | 'rejected' | 'completed';

export interface Booking {
  id: string;
  name: string;
  phone: string;
  email: string;
  date: string;
  time: string;
  guests: number;
  seating_preference?: string;
  special_requests?: string;
  status: BookingStatus;
  created_at: string;
}

export type UserRole = 'admin' | 'staff' | 'vip_patron' | 'member';

export interface User {
  id: string;
  username: string;
  email: string;
  full_name: string;
  password_hash: string;
  role: UserRole;
  phone?: string;
  registered_at: string;
}

export interface AuditLog {
  id: string;
  action: string;
  details: string;
  user: string;
  timestamp: string;
}

export interface ActivityLog {
  id: string;
  ip_address: string;
  page_url: string;
  action: string;
  user_agent: string;
  created_at: string;
}

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
  specialNote?: string;
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  isConnected: boolean;
  lastTested?: string;
}
