/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CartProvider, useCart } from './context/CartContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { SQLSchemaModal } from './components/SQLSchemaModal';
import { SiteGatePage } from './pages/SiteGatePage';
import { HomePage } from './pages/HomePage';
import { MenuPage } from './pages/MenuPage';
import { BookingPage } from './pages/BookingPage';
import { ChefPage } from './pages/ChefPage';
import { ContactPage } from './pages/ContactPage';
import { AdminPage } from './pages/AdminPage';
import { dbService, AuthenticatedUser } from './services/db';
import { logActivity } from './services/logger';
import { Check, X } from 'lucide-react';

function AppContent() {
  const [currentUser, setCurrentUser] = useState<AuthenticatedUser | null>(() => {
    return dbService.getCurrentUser();
  });

  const [currentTab, setCurrentTab] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase().replace('#', '');
      if (path === '/admin' || hash === 'admin') return 'admin';
      if (hash === 'menu' || path === '/menu') return 'menu';
      if (hash === 'book' || hash === 'booking' || path === '/book') return 'book';
      if (hash === 'contact' || path === '/contact') return 'contact';
      if (hash === 'chef' || path === '/chef') return 'chef';
    }
    return 'home';
  });

  const [isSQLModalOpen, setIsSQLModalOpen] = useState(false);
  const { toastMessage, dismissToast } = useCart();

  // Listen to popstate / hashchange
  useEffect(() => {
    const handleLocationChange = () => {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase().replace('#', '');
      if (path === '/admin' || hash === 'admin') {
        setCurrentTab('admin');
      } else if (hash === 'menu' || path === '/menu') {
        setCurrentTab('menu');
      } else if (hash === 'book' || hash === 'booking') {
        setCurrentTab('book');
      } else if (hash === 'contact') {
        setCurrentTab('contact');
      } else if (hash === 'chef') {
        setCurrentTab('chef');
      }
    };

    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  // Track page visit on tab change
  useEffect(() => {
    if (currentUser) {
      const pagePath = currentTab === 'home' ? '/' : `/${currentTab}`;
      const actionName = `PAGE_VIEW: ${currentTab.toUpperCase()}`;
      logActivity(actionName, pagePath);
    }
  }, [currentTab, currentUser]);

  const handleSelectTab = (tab: string) => {
    setCurrentTab(tab);
    window.location.hash = tab === 'home' ? '' : tab;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleUnlock = (user: AuthenticatedUser) => {
    setCurrentUser(user);
  };

  const handleLogout = () => {
    if (currentUser) {
      logActivity(`LOGOUT: User "${currentUser.username}" signed out`, window.location.pathname || '/');
    }
    dbService.logoutUser();
    setCurrentUser(null);
    setCurrentTab('home');
  };

  // SECURITY GATE: If not authenticated, ONLY the login gate is displayed!
  if (!currentUser) {
    return <SiteGatePage onUnlock={handleUnlock} />;
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-zinc-100 flex flex-col justify-between selection:bg-[#ff5a1f] selection:text-white relative">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#18181b] border border-[#ff5a1f]/40 text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-in slide-in-from-bottom-5 duration-300">
          <div className="w-6 h-6 rounded-full bg-[#ff5a1f]/20 text-[#ff5a1f] flex items-center justify-center">
            <Check className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-medium text-zinc-200">{toastMessage}</span>
          <button
            onClick={dismissToast}
            className="text-zinc-500 hover:text-white ml-2 p-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Navbar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={handleSelectTab}
        onOpenSQLModal={() => setIsSQLModalOpen(true)}
        currentUser={currentUser}
        onLogout={handleLogout}
      />

      {/* View Container */}
      <main className="flex-1">
        {currentTab === 'home' && <HomePage onSelectTab={handleSelectTab} />}
        {currentTab === 'menu' && <MenuPage onSelectTab={handleSelectTab} />}
        {currentTab === 'book' && <BookingPage onSelectTab={handleSelectTab} />}
        {currentTab === 'chef' && <ChefPage onSelectTab={handleSelectTab} />}
        {currentTab === 'contact' && <ContactPage />}
        {currentTab === 'admin' && (
          <AdminPage
            onOpenSQLModal={() => setIsSQLModalOpen(true)}
            onSelectTab={handleSelectTab}
          />
        )}
      </main>

      {/* Cart Drawer */}
      <CartDrawer
        onNavigateToMenu={() => handleSelectTab('menu')}
        onNavigateToBooking={() => handleSelectTab('book')}
      />

      {/* SQL & Supabase Schema Modal */}
      <SQLSchemaModal
        isOpen={isSQLModalOpen}
        onClose={() => setIsSQLModalOpen(false)}
      />

      {/* Luxury Footer */}
      <Footer
        onSelectTab={handleSelectTab}
        onOpenSQLModal={() => setIsSQLModalOpen(true)}
      />
    </div>
  );
}

export default function App() {
  return (
    <CartProvider>
      <AppContent />
    </CartProvider>
  );
}
