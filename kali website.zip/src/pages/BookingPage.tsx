import React, { useState } from 'react';
import { dbService } from '../services/db';
import { Booking } from '../types';
import { logActivity } from '../services/logger';
import { Calendar, Users, Clock, Mail, Phone, User, CheckCircle2, Sparkles, MapPin, ShieldCheck, ArrowRight, AlertCircle } from 'lucide-react';
import confetti from 'canvas-confetti';

interface BookingPageProps {
  onSelectTab: (tab: string) => void;
}

export const BookingPage: React.FC<BookingPageProps> = ({ onSelectTab }) => {
  const todayStr = new Date().toISOString().split('T')[0];

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    date: todayStr,
    time: '19:30',
    guests: 2,
    seating_preference: "Chef's Counter",
    special_requests: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);

  const seatingOptions = [
    { id: "Chef's Counter", label: "Chef's Counter", desc: "Front-row view of the live binchotan charcoal hearth" },
    { id: "Intimate Booth", label: "Intimate Booth", desc: "Velvet partitioned seclusion with acoustic dampening" },
    { id: "Main Dining Hall", label: "Main Dining Hall", desc: "Grand ceiling chandelier & vibrant salon atmosphere" },
    { id: "Garden Terrace", label: "Garden Terrace", desc: "Heated botanical conservatory with lantern lighting" }
  ];

  const timeSlots = [
    // Lunch
    { time: '12:00', label: '12:00 PM (Lunch)' },
    { time: '12:30', label: '12:30 PM (Lunch)' },
    { time: '13:00', label: '1:00 PM (Lunch)' },
    { time: '13:30', label: '1:30 PM (Lunch)' },
    // Dinner
    { time: '18:00', label: '6:00 PM (Early Dinner)' },
    { time: '18:30', label: '6:30 PM (Dinner)' },
    { time: '19:00', label: '7:00 PM (Dinner)' },
    { time: '19:30', label: '7:30 PM (Peak Dinner)' },
    { time: '20:00', label: '8:00 PM (Peak Dinner)' },
    { time: '20:30', label: '8:30 PM (Dinner)' },
    { time: '21:00', label: '9:00 PM (Late Dinner)' },
    { time: '21:30', label: '9:30 PM (Late Sitting)' }
  ];

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    // Name validation
    if (!formData.name.trim() || formData.name.trim().length < 2) {
      newErrors.name = 'Please provide a valid full name (minimum 2 characters)';
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim() || !emailRegex.test(formData.email.trim())) {
      newErrors.email = 'Please provide a valid email address';
    }

    // Phone validation
    const phoneClean = formData.phone.replace(/[\s()-]/g, '');
    if (!phoneClean || phoneClean.length < 7) {
      newErrors.phone = 'Please provide a valid telephone number';
    }

    // Date validation (not in the past)
    if (!formData.date || formData.date < todayStr) {
      newErrors.date = 'Reservation date cannot be in the past';
    }

    // Guests validation
    if (formData.guests < 1 || formData.guests > 20) {
      newErrors.guests = 'Guests count must be between 1 and 20';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    try {
      // Save directly to database
      const newBooking = await dbService.createBooking({
        name: formData.name.trim(),
        phone: formData.phone.trim(),
        email: formData.email.trim(),
        date: formData.date,
        time: formData.time,
        guests: Number(formData.guests),
        seating_preference: formData.seating_preference,
        special_requests: formData.special_requests.trim()
      });

      setConfirmedBooking(newBooking);

      // Log booking activity
      logActivity(
        `BOOKING_SUBMITTED: Table for ${formData.guests} guests by "${formData.name.trim()}" (${formData.date} at ${formData.time})`,
        '/book'
      );

      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.55 },
        colors: ['#ff5a1f', '#f59e0b', '#d97706', '#ffffff']
      });
    } catch (err) {
      setErrors({ form: 'An unexpected error occurred while reserving. Please try again.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setConfirmedBooking(null);
    setFormData({
      name: '',
      phone: '',
      email: '',
      date: todayStr,
      time: '19:30',
      guests: 2,
      seating_preference: "Chef's Counter",
      special_requests: ''
    });
    setErrors({});
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-[#ff5a1f] uppercase tracking-widest font-semibold">
          <Calendar className="w-3.5 h-3.5" />
          <span>Bespoke Table Seating</span>
        </div>
        <h1 className="text-4xl sm:text-6xl font-serif-luxury font-bold text-white tracking-tight">
          Reserve Your Experience
        </h1>
        <p className="text-sm text-zinc-400 font-light leading-relaxed">
          Allow us the honor of hosting your evening. Tables are held for 15 minutes past reservation time. For parties exceeding 12 guests, our private dining concierge will arrange tailored menus.
        </p>
      </div>

      {confirmedBooking ? (
        /* Confirmed Luxury Reservation Voucher */
        <div className="bg-[#121212] border border-[#ff5a1f]/40 rounded-3xl p-8 sm:p-12 shadow-2xl space-y-8 animate-in fade-in duration-500 text-white">
          <div className="text-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-[#ff5a1f]/15 border border-[#ff5a1f]/40 flex items-center justify-center text-[#ff5a1f] mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <span className="text-xs uppercase tracking-widest text-[#ff5a1f] font-semibold">
              Reservation Saved to Database
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-white">
              We Look Forward to Welcoming You
            </h2>
            <p className="text-xs text-zinc-400 max-w-md mx-auto">
              A confirmation notification has been dispatched to your email and registered in the kali concierge roster.
            </p>
          </div>

          {/* Luxury Voucher Card */}
          <div className="max-w-xl mx-auto bg-black/60 border border-white/10 rounded-2xl p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <span className="text-[10px] uppercase tracking-widest text-zinc-500 font-mono">Reference Code</span>
                <p className="text-xl font-mono font-bold text-[#ff5a1f]">{confirmedBooking.id}</p>
              </div>
              <div className="text-right">
                <span className="text-[10px] uppercase tracking-widest text-zinc-500 font-mono">Status</span>
                <p className="text-xs font-semibold uppercase tracking-wider text-amber-400">
                  {confirmedBooking.status} (Reserved)
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-zinc-500 block mb-0.5">Guest Principal</span>
                <span className="font-semibold text-white">{confirmedBooking.name}</span>
              </div>
              <div>
                <span className="text-zinc-500 block mb-0.5">Party Size</span>
                <span className="font-semibold text-white">{confirmedBooking.guests} Guests</span>
              </div>
              <div>
                <span className="text-zinc-500 block mb-0.5">Date & Time</span>
                <span className="font-semibold text-white">{confirmedBooking.date} at {confirmedBooking.time}</span>
              </div>
              <div>
                <span className="text-zinc-500 block mb-0.5">Atmosphere</span>
                <span className="font-semibold text-white">{confirmedBooking.seating_preference}</span>
              </div>
              <div>
                <span className="text-zinc-500 block mb-0.5">Contact</span>
                <span className="font-semibold text-zinc-300 truncate block">{confirmedBooking.email}</span>
              </div>
              <div>
                <span className="text-zinc-500 block mb-0.5">Phone</span>
                <span className="font-semibold text-zinc-300">{confirmedBooking.phone}</span>
              </div>
            </div>

            {confirmedBooking.special_requests && (
              <div className="p-3 bg-[#18181b] rounded-xl border border-white/5 text-xs text-zinc-300">
                <span className="text-zinc-500 text-[11px] block mb-0.5 font-medium">Guest Notes:</span>
                "{confirmedBooking.special_requests}"
              </div>
            )}
          </div>

          {/* Action Row */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button
              onClick={() => onSelectTab('menu')}
              className="w-full sm:w-auto px-6 py-3 rounded-full bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-semibold tracking-wider uppercase transition-all shadow-lg shadow-[#ff5a1f]/20 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Explore Tasting Menu to Pre-Select</span>
            </button>
            <button
              onClick={handleReset}
              className="w-full sm:w-auto px-6 py-3 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-xs font-medium tracking-wider uppercase transition-all border border-white/10 cursor-pointer"
            >
              Make Another Reservation
            </button>
            <button
              onClick={() => onSelectTab('admin')}
              className="text-xs text-zinc-500 hover:text-[#ff5a1f] transition-colors"
            >
              View in Admin Panel →
            </button>
          </div>
        </div>
      ) : (
        /* Reservation Form */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form (2 cols) */}
          <div className="lg:col-span-2 bg-[#121212] border border-white/10 rounded-3xl p-6 sm:p-10 shadow-xl">
            <form onSubmit={handleSubmit} className="space-y-6">
              {errors.form && (
                <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{errors.form}</span>
                </div>
              )}

              {/* Guest Details */}
              <div className="space-y-4">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-200 border-b border-white/10 pb-2">
                  1. Guest Information
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name */}
                  <div>
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-[#ff5a1f]" />
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Lord Arthur Sterling"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className={`w-full bg-black/60 border rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none transition-colors ${
                        errors.name ? 'border-rose-500' : 'border-white/10 focus:border-[#ff5a1f]'
                      }`}
                    />
                    {errors.name && <p className="text-[11px] text-rose-400 mt-1">{errors.name}</p>}
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-[#ff5a1f]" />
                      Telephone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+1 (555) 234-5678"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className={`w-full bg-black/60 border rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none transition-colors ${
                        errors.phone ? 'border-rose-500' : 'border-white/10 focus:border-[#ff5a1f]'
                      }`}
                    />
                    {errors.phone && <p className="text-[11px] text-rose-400 mt-1">{errors.phone}</p>}
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-[#ff5a1f]" />
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="name@domain.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className={`w-full bg-black/60 border rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none transition-colors ${
                      errors.email ? 'border-rose-500' : 'border-white/10 focus:border-[#ff5a1f]'
                    }`}
                  />
                  {errors.email && <p className="text-[11px] text-rose-400 mt-1">{errors.email}</p>}
                </div>
              </div>

              {/* Reservation Timing */}
              <div className="space-y-4 pt-4">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-200 border-b border-white/10 pb-2">
                  2. Date, Time & Party Size
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* Date */}
                  <div>
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#ff5a1f]" />
                      Date *
                    </label>
                    <input
                      type="date"
                      required
                      min={todayStr}
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      className="w-full bg-black/60 border border-white/10 focus:border-[#ff5a1f] rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none"
                    />
                    {errors.date && <p className="text-[11px] text-rose-400 mt-1">{errors.date}</p>}
                  </div>

                  {/* Time */}
                  <div>
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-[#ff5a1f]" />
                      Sitting Time *
                    </label>
                    <select
                      value={formData.time}
                      onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                      className="w-full bg-black/60 border border-white/10 focus:border-[#ff5a1f] rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none"
                    >
                      {timeSlots.map((slot) => (
                        <option key={slot.time} value={slot.time} className="bg-zinc-900 text-white">
                          {slot.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Guests */}
                  <div>
                    <label className="block text-xs font-medium text-zinc-400 mb-1.5 flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-[#ff5a1f]" />
                      Guests *
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="20"
                      required
                      value={formData.guests}
                      onChange={(e) => setFormData({ ...formData, guests: parseInt(e.target.value) || 1 })}
                      className="w-full bg-black/60 border border-white/10 focus:border-[#ff5a1f] rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none"
                    />
                    {errors.guests && <p className="text-[11px] text-rose-400 mt-1">{errors.guests}</p>}
                  </div>
                </div>
              </div>

              {/* Seating Preference */}
              <div className="space-y-3 pt-4">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-zinc-200 border-b border-white/10 pb-2">
                  3. Salon & Seating Ambience
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {seatingOptions.map((opt) => (
                    <label
                      key={opt.id}
                      className={`p-3.5 rounded-xl border flex flex-col cursor-pointer transition-all ${
                        formData.seating_preference === opt.id
                          ? 'bg-[#ff5a1f]/15 border-[#ff5a1f] text-white shadow-md'
                          : 'bg-black/40 border-white/10 text-zinc-400 hover:border-white/25'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-semibold text-white">{opt.label}</span>
                        <input
                          type="radio"
                          name="seating"
                          checked={formData.seating_preference === opt.id}
                          onChange={() => setFormData({ ...formData, seating_preference: opt.id })}
                          className="accent-[#ff5a1f]"
                        />
                      </div>
                      <span className="text-[11px] text-zinc-400 leading-snug">{opt.desc}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Special Requests */}
              <div className="space-y-2 pt-4">
                <label className="block text-xs font-medium text-zinc-400">
                  Special Occasion, Allergies or Dietary Requests
                </label>
                <textarea
                  rows={3}
                  placeholder="e.g. Celebrating an anniversary; one guest requires gluten-free pairings; interest in the Grand Cru cellar."
                  value={formData.special_requests}
                  onChange={(e) => setFormData({ ...formData, special_requests: e.target.value })}
                  className="w-full bg-black/60 border border-white/10 focus:border-[#ff5a1f] rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none resize-none"
                />
              </div>

              {/* Submit Button */}
              <div className="pt-4">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 px-6 rounded-xl bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-bold tracking-widest uppercase transition-all shadow-xl shadow-[#ff5a1f]/25 flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
                >
                  {isSubmitting ? (
                    <span>Registering with Concierge...</span>
                  ) : (
                    <>
                      <Calendar className="w-4 h-4" />
                      <span>Confirm Table Reservation</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Sidebar / Concierge Guidelines (1 col) */}
          <div className="space-y-6">
            <div className="bg-[#121212] border border-white/10 rounded-3xl p-6 text-white space-y-4 shadow-xl">
              <div className="flex items-center gap-2 text-[#ff5a1f]">
                <ShieldCheck className="w-5 h-5" />
                <h4 className="text-sm font-semibold tracking-wide uppercase">Hospitality Protocol</h4>
              </div>

              <div className="space-y-3 text-xs text-zinc-400 leading-relaxed">
                <div>
                  <span className="text-zinc-200 font-medium block">Dress Code</span>
                  <span>Smart Elegant. We kindly request guests refrain from athletic wear and beachwear.</span>
                </div>
                <div>
                  <span className="text-zinc-200 font-medium block">Grace Period</span>
                  <span>Tables are reserved for 15 minutes past the confirmed sitting time before reallocation.</span>
                </div>
                <div>
                  <span className="text-zinc-200 font-medium block">Complimentary Valet</span>
                  <span>Porte-cochère valet service is provided at 142 Regent Boulevard for all dining guests.</span>
                </div>
                <div>
                  <span className="text-zinc-200 font-medium block">Dietary Inquiries</span>
                  <span>Our culinary atelier gladly accommodates vegan, vegetarian, halal, and celiac requirements with advance notice.</span>
                </div>
              </div>
            </div>

            <div className="bg-black/40 border border-white/10 rounded-3xl p-6 text-white space-y-3">
              <span className="text-[11px] font-mono uppercase tracking-widest text-[#ff5a1f]">
                Direct Concierge Desk
              </span>
              <p className="text-xs text-zinc-300">
                For urgent same-day bookings or private salon buyouts:
              </p>
              <div className="pt-1">
                <span className="block text-base font-serif-luxury font-bold text-white">+1 (555) 794-KALI</span>
                <span className="text-xs text-zinc-500">concierge@kali-restaurant.com</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
