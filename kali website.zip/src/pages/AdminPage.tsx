import React, { useState, useEffect } from 'react';
import { MenuItem, Booking, AuditLog, MenuCategory, BookingStatus, User, UserRole, ActivityLog } from '../types';
import { dbService, AuthenticatedUser, hashPassword, ADMIN_PASSWORD_HASH, isUserAdmin, SUPER_ADMIN_EMAIL, SUPER_ADMIN_USERNAME } from '../services/db';
import { logActivity, parseBrowser } from '../services/logger';
import {
  ShieldCheck,
  ShieldAlert,
  Lock,
  User as UserIcon,
  LayoutDashboard,
  UtensilsCrossed,
  CalendarCheck,
  History,
  Database,
  Plus,
  Pencil,
  Trash2,
  CheckCircle,
  XCircle,
  Clock,
  Sparkles,
  Search,
  LogOut,
  RefreshCw,
  AlertCircle,
  Copy,
  Check,
  Eye,
  SlidersHorizontal,
  Users,
  Activity,
  Globe,
  Download,
  Filter,
  Terminal,
  ExternalLink,
  ArrowLeft,
  Key,
  UserCheck
} from 'lucide-react';

interface AdminPageProps {
  onOpenSQLModal: () => void;
  onSelectTab?: (tab: string) => void;
}

export const AdminPage: React.FC<AdminPageProps> = ({ onOpenSQLModal, onSelectTab }) => {
  // Authentication State
  const [currentUser, setCurrentUser] = useState<AuthenticatedUser | null>(() => {
    return dbService.getCurrentUser();
  });
  const [showAdminLoginForm, setShowAdminLoginForm] = useState(false);

  const isAuthorizedAdmin = isUserAdmin(currentUser);

  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Admin Active Tab
  const [activeTab, setActiveTab] = useState<'dashboard' | 'menu' | 'bookings' | 'users' | 'activity_logs' | 'logs' | 'database'>('dashboard');

  // Data States
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [loadingData, setLoadingData] = useState(false);

  // Activity Logs Controls
  const [activitySearch, setActivitySearch] = useState('');
  const [activityActionFilter, setActivityActionFilter] = useState<'all' | 'page_view' | 'booking' | 'login' | 'cart'>('all');
  const [copiedIp, setCopiedIp] = useState<string | null>(null);

  // User Management States
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<string>('all');
  const [isCreatingUser, setIsCreatingUser] = useState(false);
  const [userForm, setUserForm] = useState({
    username: '',
    email: '',
    full_name: '',
    password: 'password123',
    role: 'member' as UserRole,
    phone: '+1 (555) 000-0000'
  });

  // Menu Management States
  const [menuSearch, setMenuSearch] = useState('');
  const [menuCategoryFilter, setMenuCategoryFilter] = useState<string>('All');
  const [isEditingMenu, setIsEditingMenu] = useState<MenuItem | null>(null);
  const [isCreatingMenu, setIsCreatingMenu] = useState(false);
  const [menuForm, setMenuForm] = useState<Omit<MenuItem, 'id'>>({
    name: '',
    description: '',
    price: 30,
    category: 'Veg',
    image_url: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80',
    is_special: false,
    calories: 450,
    prep_time: '20 min'
  });

  // Bookings Filter
  const [bookingStatusFilter, setBookingStatusFilter] = useState<string>('all');
  const [bookingSearch, setBookingSearch] = useState('');
  const [selectedBookingNotes, setSelectedBookingNotes] = useState<Booking | null>(null);

  // SQL Copy Feedback
  const [copiedSQL, setCopiedSQL] = useState(false);

  // Load all data
  const refreshData = async () => {
    setLoadingData(true);
    try {
      const [m, b, u, act] = await Promise.all([
        dbService.getMenuItems(),
        dbService.getBookings(),
        dbService.getUsers(),
        dbService.getActivityLogs()
      ]);
      setMenuItems(m);
      setBookings(b);
      setUsers(u);
      setLogs(dbService.getLogs());
      setActivityLogs(act);
    } finally {
      setLoadingData(false);
    }
  };

  useEffect(() => {
    if (isAuthorizedAdmin) {
      refreshData();
    }
  }, [isAuthorizedAdmin]);

  // Handle Login with Secure Password Hashing & Strict Admin Authorization
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    setLoginError(null);

    try {
      const result = await dbService.authenticateUser(loginUsername, loginPassword);
      if (result.success && result.user) {
        if (!isUserAdmin(result.user)) {
          const deniedMsg = `Access Denied: Account "@${result.user.username}" is a dining patron (${result.user.role}). Administrator console is strictly restricted to Super Administrator (${SUPER_ADMIN_EMAIL}).`;
          logActivity(`ADMIN_LOGIN_DENIED: Patron "@${result.user.username}" attempted admin console access`, '/admin');
          setLoginError(deniedMsg);
          return;
        }

        logActivity(`ADMIN_LOGIN_SUCCESS: Administrator "${loginUsername.trim()}" authenticated`, '/admin');
        setCurrentUser(result.user);
        setShowAdminLoginForm(false);
      } else {
        const err = result.error || 'Authentication failed. Please verify credentials.';
        logActivity(`ADMIN_LOGIN_FAILED: Administrator credentials rejected for "${loginUsername.trim()}"`, '/admin');
        setLoginError(err);
      }
    } catch {
      logActivity(`ADMIN_LOGIN_FAILED: Service error for "${loginUsername.trim()}"`, '/admin');
      setLoginError('Authentication service failed. Please try again.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = () => {
    if (currentUser) {
      logActivity(`ADMIN_LOGOUT: Administrator "${currentUser.username}" logged out`, '/admin');
    }
    dbService.logoutUser();
    setCurrentUser(null);
    setShowAdminLoginForm(false);
  };

  const handleClearActivityLogs = async () => {
    if (window.confirm('Are you sure you want to clear all activity logs? This action cannot be undone.')) {
      await dbService.clearActivityLogs();
      setActivityLogs([]);
      logActivity('ACTIVITY_LOGS_CLEARED: Administrator cleared activity logs', '/admin');
    }
  };

  const handleExportActivityCSV = () => {
    if (activityLogs.length === 0) return;
    const headers = ['ID', 'Timestamp', 'IP Address', 'Page URL', 'Action', 'Browser / User Agent'];
    const rows = activityLogs.map(l => [
      `"${l.id}"`,
      `"${l.created_at}"`,
      `"${l.ip_address}"`,
      `"${l.page_url}"`,
      `"${l.action.replace(/"/g, '""')}"`,
      `"${l.user_agent.replace(/"/g, '""')}"`
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `kali_activity_logs_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // --- MENU ACTIONS ---
  const handleSaveMenu = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!menuForm.name.trim() || menuForm.price <= 0) return;

    if (isEditingMenu) {
      await dbService.updateMenuItem({
        ...menuForm,
        id: isEditingMenu.id
      });
      setIsEditingMenu(null);
    } else {
      await dbService.addMenuItem(menuForm);
      setIsCreatingMenu(false);
    }

    await refreshData();
  };

  const handleDeleteMenu = async (id: string, name: string) => {
    if (confirm(`Are you sure you wish to delete "${name}" from the menu?`)) {
      await dbService.deleteMenuItem(id);
      await refreshData();
    }
  };

  const handleResetMenu = async () => {
    if (confirm('Reset all menu items to the original 12 5-star signature dishes?')) {
      await dbService.resetMenuToDefaults();
      await refreshData();
    }
  };

  const openEditModal = (item: MenuItem) => {
    setIsEditingMenu(item);
    setMenuForm({
      name: item.name,
      description: item.description,
      price: item.price,
      category: item.category,
      image_url: item.image_url,
      is_special: item.is_special,
      calories: item.calories || 450,
      prep_time: item.prep_time || '20 min'
    });
  };

  const openCreateModal = () => {
    setIsCreatingMenu(true);
    setMenuForm({
      name: '',
      description: '',
      price: 35,
      category: 'Veg',
      image_url: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80',
      is_special: false,
      calories: 450,
      prep_time: '20 min'
    });
  };

  // --- BOOKING ACTIONS ---
  const handleUpdateBookingStatus = async (id: string, status: BookingStatus) => {
    await dbService.updateBookingStatus(id, status);
    await refreshData();
  };

  const handleDeleteBooking = async (id: string) => {
    if (confirm(`Delete reservation record ${id}?`)) {
      await dbService.deleteBooking(id);
      await refreshData();
    }
  };

  // --- USER ACTIONS ---
  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userForm.username.trim() || !userForm.email.trim()) return;

    const hash = await hashPassword(userForm.password.trim() || 'password123');
    await dbService.addUser({
      username: userForm.username.trim().toLowerCase(),
      email: userForm.email.trim().toLowerCase(),
      full_name: userForm.full_name.trim() || userForm.username.trim(),
      password_hash: hash,
      role: userForm.role,
      phone: userForm.phone.trim()
    });

    setIsCreatingUser(false);
    setUserForm({
      username: '',
      email: '',
      full_name: '',
      password: 'password123',
      role: 'member',
      phone: '+1 (555) 000-0000'
    });
    await refreshData();
  };

  const handleDeleteUser = async (id: string, username: string) => {
    if (confirm(`Delete registered user account "${username}"?`)) {
      await dbService.deleteUser(id);
      await refreshData();
    }
  };

  const handleResetUsers = async () => {
    if (confirm('Reset registered users database to initial mock members?')) {
      await dbService.resetUsers();
      await refreshData();
    }
  };

  // --- LOG ACTIONS ---
  const handleClearLogs = () => {
    if (confirm('Clear audit history?')) {
      dbService.clearLogs();
      setLogs(dbService.getLogs());
    }
  };

  // Metrics Calculations
  const todayStr = new Date().toISOString().split('T')[0];
  const totalBookingsCount = bookings.length;
  const todayBookingsCount = bookings.filter(b => b.date === todayStr).length;
  const pendingBookingsCount = bookings.filter(b => b.status === 'pending').length;
  const confirmedBookingsCount = bookings.filter(b => b.status === 'confirmed').length;

  // Filtered Bookings
  const filteredBookings = bookings.filter(b => {
    const matchesStatus = bookingStatusFilter === 'all' || b.status === bookingStatusFilter;
    const matchesSearch =
      b.name.toLowerCase().includes(bookingSearch.toLowerCase()) ||
      b.phone.toLowerCase().includes(bookingSearch.toLowerCase()) ||
      b.id.toLowerCase().includes(bookingSearch.toLowerCase()) ||
      b.email.toLowerCase().includes(bookingSearch.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  // Filtered Users
  const filteredUsers = users.filter(u => {
    const matchesRole = userRoleFilter === 'all' || u.role === userRoleFilter;
    const matchesSearch =
      u.username.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.full_name.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.id.toLowerCase().includes(userSearch.toLowerCase());
    return matchesRole && matchesSearch;
  });

  // Filtered Menu
  const filteredMenu = menuItems.filter(m => {
    const matchesCat = menuCategoryFilter === 'All' || m.category === menuCategoryFilter;
    const matchesSearch =
      m.name.toLowerCase().includes(menuSearch.toLowerCase()) ||
      m.description.toLowerCase().includes(menuSearch.toLowerCase());
    return matchesCat && matchesSearch;
  });

  // Filtered Activity Logs
  const filteredActivityLogs = activityLogs.filter((log) => {
    if (activityActionFilter === 'page_view' && !log.action.toUpperCase().includes('PAGE_VIEW')) return false;
    if (activityActionFilter === 'booking' && !log.action.toUpperCase().includes('BOOKING')) return false;
    if (activityActionFilter === 'login' && !log.action.toUpperCase().includes('LOGIN') && !log.action.toUpperCase().includes('REGISTRATION')) return false;
    if (activityActionFilter === 'cart' && !log.action.toUpperCase().includes('CART')) return false;

    if (activitySearch.trim()) {
      const q = activitySearch.toLowerCase();
      const matchIp = log.ip_address.toLowerCase().includes(q);
      const matchAction = log.action.toLowerCase().includes(q);
      const matchPage = log.page_url.toLowerCase().includes(q);
      const matchUa = log.user_agent.toLowerCase().includes(q);
      return matchIp || matchAction || matchPage || matchUa;
    }
    return true;
  });

  const uniqueIpsCount = Array.from(new Set(activityLogs.map(l => l.ip_address))).length;
  const pageViewsCount = activityLogs.filter(l => l.action.toUpperCase().includes('PAGE_VIEW')).length;
  const cartEventsCount = activityLogs.filter(l => l.action.toUpperCase().includes('CART')).length;
  const authEventsCount = activityLogs.filter(l => l.action.toUpperCase().includes('LOGIN') || l.action.toUpperCase().includes('REGISTRATION')).length;
  const bookingEventsCount = activityLogs.filter(l => l.action.toUpperCase().includes('BOOKING')).length;

  // --- VIEW 1: NORMAL PATRON ACCESS DENIED (403 FORBIDDEN) ---
  if (currentUser && !isAuthorizedAdmin && !showAdminLoginForm) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-lg bg-[#121212] border border-rose-500/30 rounded-3xl p-8 sm:p-10 shadow-2xl text-white space-y-6 relative overflow-hidden">
          <div className="absolute -top-24 -right-24 w-48 h-48 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="text-center space-y-3">
            <div className="w-16 h-16 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 mx-auto mb-2 shadow-lg shadow-rose-950/40">
              <ShieldAlert className="w-8 h-8" />
            </div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[11px] font-mono uppercase tracking-wider">
              <span>HTTP 403 • Restricted Area</span>
            </div>
            <h1 className="text-2xl font-serif-luxury font-bold text-white tracking-wide">
              Administrator Access Only
            </h1>
            <p className="text-xs text-zinc-400 max-w-sm mx-auto leading-relaxed">
              This terminal controls menus, reservations, live telemetry logs, and database schemas. Dining patrons do not have administrative access.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-black/60 border border-white/10 space-y-3">
            <div className="text-[11px] uppercase tracking-wider text-zinc-400 font-semibold flex items-center justify-between border-b border-white/5 pb-2">
              <span>Current Patron Account</span>
              <span className="text-amber-400 font-mono text-[10px] uppercase bg-amber-400/10 border border-amber-400/20 px-2 py-0.5 rounded">
                Tier: {currentUser.role}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-zinc-500 block text-[10px]">Patron Name:</span>
                <span className="text-white font-medium">{currentUser.displayName}</span>
              </div>
              <div>
                <span className="text-zinc-500 block text-[10px]">Username:</span>
                <span className="text-zinc-300 font-mono">@{currentUser.username}</span>
              </div>
              <div className="col-span-2">
                <span className="text-zinc-500 block text-[10px]">Electronic Mail:</span>
                <span className="text-zinc-300 font-mono">{currentUser.email || 'N/A'}</span>
              </div>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-zinc-900/80 border border-white/5 text-zinc-400 text-xs flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-[#ff5a1f] mt-0.5 flex-shrink-0" />
            <span className="leading-relaxed">
              Administration is strictly restricted to Super Administrator (<strong className="text-white font-mono">{SUPER_ADMIN_EMAIL}</strong>).
            </span>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              onClick={() => onSelectTab ? onSelectTab('home') : (window.location.hash = '')}
              className="flex-1 py-3 px-4 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer border border-white/10"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Return to Dining</span>
            </button>
            <button
              onClick={() => setShowAdminLoginForm(true)}
              className="flex-1 py-3 px-4 rounded-xl bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-bold uppercase tracking-wider transition-all shadow-lg shadow-[#ff5a1f]/20 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Key className="w-3.5 h-3.5" />
              <span>Sign In as Admin</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // --- VIEW 2: ADMIN LOGIN GATE ---
  if (!isAuthorizedAdmin || showAdminLoginForm) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md bg-[#121212] border border-white/10 rounded-3xl p-8 sm:p-10 shadow-2xl text-white space-y-6">
          <div className="text-center space-y-2">
            <div className="w-14 h-14 rounded-2xl bg-[#ff5a1f]/10 border border-[#ff5a1f]/30 flex items-center justify-center text-[#ff5a1f] mx-auto mb-3">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <h1 className="text-2xl font-serif-luxury font-bold text-white tracking-wide">
              kali Atelier Portal
            </h1>
            <p className="text-xs text-zinc-400">
              Super Administrator Access (<span className="text-[#ff5a1f] font-mono">{SUPER_ADMIN_EMAIL}</span>)
            </p>
          </div>

          {loginError && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1 flex items-center gap-1.5">
                <UserIcon className="w-3.5 h-3.5 text-[#ff5a1f]" />
                Administrator Username or Email
              </label>
              <input
                type="text"
                required
                placeholder="ktg17178 or ktg17178@gmail.com"
                value={loginUsername}
                onChange={(e) => setLoginUsername(e.target.value)}
                className="w-full bg-black/60 border border-white/10 focus:border-[#ff5a1f] rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-[#ff5a1f]" />
                Administrator Password
              </label>
              <input
                type="password"
                required
                placeholder="Enter admin password"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full bg-black/60 border border-white/10 focus:border-[#ff5a1f] rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none font-mono"
              />
            </div>

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full py-3.5 px-4 rounded-xl bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-bold uppercase tracking-wider transition-all shadow-lg shadow-[#ff5a1f]/20 flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{isLoggingIn ? 'Authenticating...' : 'Sign In as Administrator'}</span>
            </button>

            {showAdminLoginForm && (
              <button
                type="button"
                onClick={() => setShowAdminLoginForm(false)}
                className="w-full py-2 text-center text-xs text-zinc-400 hover:text-white transition-colors cursor-pointer"
              >
                Cancel and return
              </button>
            )}
          </form>

          <div className="pt-4 border-t border-white/5 text-center">
            <span className="text-[11px] text-zinc-500">
              Role validation enforced: only authorized Super Administrator allowed.
            </span>
          </div>
        </div>
      </div>
    );
  }

  // --- AUTHENTICATED ADMIN PANEL ---
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Top Admin Bar */}
      <div className="bg-[#121212] border border-white/10 rounded-2xl p-4 sm:p-6 flex flex-col md:flex-row items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#ff5a1f]/10 border border-[#ff5a1f]/30 flex items-center justify-center text-[#ff5a1f]">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-serif-luxury font-bold text-white">kali Administration</h1>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-mono border border-emerald-500/20">
                Super Admin Authorized
              </span>
            </div>
            <p className="text-xs text-zinc-400">
              Authenticated Admin: <strong className="text-[#ff5a1f]">@{currentUser?.username}</strong> ({currentUser?.email || SUPER_ADMIN_EMAIL})
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={refreshData}
            disabled={loadingData}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 hover:border-white/20 text-xs text-zinc-300 hover:text-white transition-colors cursor-pointer"
            title="Refresh database records"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#ff5a1f] ${loadingData ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          <button
            onClick={onOpenSQLModal}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 hover:border-white/20 text-xs text-zinc-300 hover:text-white transition-colors cursor-pointer"
          >
            <Database className="w-3.5 h-3.5 text-[#ff5a1f]" />
            <span>Database SQL</span>
          </button>

          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500/20 text-xs text-rose-400 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Log Out</span>
          </button>
        </div>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="flex overflow-x-auto gap-2 p-1.5 bg-[#121212] border border-white/10 rounded-2xl">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'dashboard'
              ? 'bg-[#ff5a1f] text-white shadow-md'
              : 'text-zinc-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Dashboard</span>
        </button>

        <button
          onClick={() => setActiveTab('bookings')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'bookings'
              ? 'bg-[#ff5a1f] text-white shadow-md'
              : 'text-zinc-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <CalendarCheck className="w-4 h-4" />
          <span>Manage Bookings ({bookings.length})</span>
          {pendingBookingsCount > 0 && (
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'users'
              ? 'bg-[#ff5a1f] text-white shadow-md'
              : 'text-zinc-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Patron Accounts ({users.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('menu')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'menu'
              ? 'bg-[#ff5a1f] text-white shadow-md'
              : 'text-zinc-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <UtensilsCrossed className="w-4 h-4" />
          <span>Manage Menu ({menuItems.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('activity_logs')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'activity_logs'
              ? 'bg-[#ff5a1f] text-white shadow-md'
              : 'text-zinc-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Activity Logs ({activityLogs.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('logs')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'logs'
              ? 'bg-[#ff5a1f] text-white shadow-md'
              : 'text-zinc-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Action Logs ({logs.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('database')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'database'
              ? 'bg-[#ff5a1f] text-white shadow-md'
              : 'text-zinc-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>Supabase / Database</span>
        </button>
      </div>

      {/* --- TAB 1: DASHBOARD --- */}
      {activeTab === 'dashboard' && (
        <div className="space-y-8 animate-in fade-in duration-300">
          {/* Key Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="bg-[#121212] border border-white/10 rounded-2xl p-6 space-y-2">
              <div className="flex items-center justify-between text-zinc-400">
                <span className="text-xs uppercase font-semibold tracking-wider">Total Bookings</span>
                <CalendarCheck className="w-4 h-4 text-[#ff5a1f]" />
              </div>
              <p className="text-3xl font-serif-luxury font-bold text-white">{totalBookingsCount}</p>
              <p className="text-[11px] text-zinc-500">Cumulative reservations registered</p>
            </div>

            <div className="bg-[#121212] border border-white/10 rounded-2xl p-6 space-y-2">
              <div className="flex items-center justify-between text-zinc-400">
                <span className="text-xs uppercase font-semibold tracking-wider">Today's Bookings</span>
                <Clock className="w-4 h-4 text-emerald-400" />
              </div>
              <p className="text-3xl font-serif-luxury font-bold text-emerald-400">{todayBookingsCount}</p>
              <p className="text-[11px] text-zinc-500">Scheduled for today's service</p>
            </div>

            <div className="bg-[#121212] border border-white/10 rounded-2xl p-6 space-y-2">
              <div className="flex items-center justify-between text-zinc-400">
                <span className="text-xs uppercase font-semibold tracking-wider">Pending Approvals</span>
                <AlertCircle className="w-4 h-4 text-amber-400" />
              </div>
              <p className="text-3xl font-serif-luxury font-bold text-amber-400">{pendingBookingsCount}</p>
              <p className="text-[11px] text-zinc-500">Awaiting concierge confirmation</p>
            </div>

            <div className="bg-[#121212] border border-white/10 rounded-2xl p-6 space-y-2">
              <div className="flex items-center justify-between text-zinc-400">
                <span className="text-xs uppercase font-semibold tracking-wider">Registered Patrons</span>
                <Users className="w-4 h-4 text-[#ff5a1f]" />
              </div>
              <p className="text-3xl font-serif-luxury font-bold text-white">{users.length}</p>
              <p className="text-[11px] text-zinc-500">VIP & member database records</p>
            </div>

            <div className="bg-[#121212] border border-white/10 rounded-2xl p-6 space-y-2">
              <div className="flex items-center justify-between text-zinc-400">
                <span className="text-xs uppercase font-semibold tracking-wider">Active Dishes</span>
                <UtensilsCrossed className="w-4 h-4 text-zinc-400" />
              </div>
              <p className="text-3xl font-serif-luxury font-bold text-white">{menuItems.length}</p>
              <p className="text-[11px] text-zinc-500">Curated 5-star culinary items</p>
            </div>
          </div>

          {/* Quick Actions & Recent Activity */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Quick Actions */}
            <div className="bg-[#121212] border border-white/10 rounded-2xl p-6 space-y-4">
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider border-b border-white/10 pb-3">
                Director Shortcuts
              </h3>
              <div className="space-y-2.5">
                <button
                  onClick={() => setIsCreatingUser(true)}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Register New Patron Account</span>
                </button>

                <button
                  onClick={() => setActiveTab('users')}
                  className="w-full py-2.5 px-4 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Users className="w-3.5 h-3.5 text-[#ff5a1f]" />
                  <span>Manage Patron Database ({users.length})</span>
                </button>

                <button
                  onClick={openCreateModal}
                  className="w-full py-2.5 px-4 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add New Menu Creation</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('bookings');
                    setBookingStatusFilter('pending');
                  }}
                  className="w-full py-2.5 px-4 rounded-xl bg-zinc-900 border border-white/10 hover:border-white/20 text-zinc-300 text-xs font-medium flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>Review Pending Bookings ({pendingBookingsCount})</span>
                </button>

                <button
                  onClick={handleResetMenu}
                  className="w-full py-2.5 px-4 rounded-xl bg-zinc-900 border border-white/10 hover:border-white/20 text-zinc-300 text-xs font-medium flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-zinc-400" />
                  <span>Reset Menu to 12 Seed Dishes</span>
                </button>
              </div>
            </div>

            {/* Recent Bookings Snapshot */}
            <div className="lg:col-span-2 bg-[#121212] border border-white/10 rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h3 className="text-sm font-semibold text-white uppercase tracking-wider">
                  Latest Table Reservations
                </h3>
                <button
                  onClick={() => setActiveTab('bookings')}
                  className="text-xs text-[#ff5a1f] hover:underline"
                >
                  View All ({bookings.length}) →
                </button>
              </div>

              <div className="space-y-3">
                {bookings.slice(0, 4).map((b) => (
                  <div
                    key={b.id}
                    className="p-3.5 rounded-xl bg-black/40 border border-white/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-white">{b.id}</span>
                        <span className="text-xs font-medium text-zinc-200">{b.name}</span>
                        <span className="text-[11px] text-zinc-400">({b.guests} guests)</span>
                      </div>
                      <p className="text-[11px] text-zinc-400 mt-0.5">
                        {b.date} at {b.time} · {b.seating_preference || 'Main Hall'}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full ${
                        b.status === 'confirmed'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : b.status === 'rejected'
                          ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      }`}>
                        {b.status}
                      </span>
                      {b.status === 'pending' && (
                        <button
                          onClick={() => handleUpdateBookingStatus(b.id, 'confirmed')}
                          className="px-2.5 py-1 rounded bg-[#ff5a1f] text-white text-[11px] font-semibold hover:bg-[#e04b14]"
                        >
                          Accept
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recent Visitor Activity Stream in Dashboard */}
          <div className="bg-[#121212] border border-white/10 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#ff5a1f]" />
                <h3 className="text-sm font-semibold text-white uppercase tracking-wider">
                  Live Visitor Activity Stream
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/20">
                  {activityLogs.length} events logged
                </span>
              </div>
              <button
                onClick={() => setActiveTab('activity_logs')}
                className="text-xs text-[#ff5a1f] hover:underline"
              >
                View Full Activity Table →
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
              {activityLogs.slice(0, 4).map((act) => {
                const browser = parseBrowser(act.user_agent);
                const isBooking = act.action.toUpperCase().includes('BOOKING');
                const isCart = act.action.toUpperCase().includes('CART');
                const isLogin = act.action.toUpperCase().includes('LOGIN');

                return (
                  <div
                    key={act.id}
                    className="p-3.5 rounded-xl bg-black/40 border border-white/5 space-y-2 flex flex-col justify-between text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[10px] text-zinc-500 font-mono">
                        <span className="text-sky-400 font-semibold">{act.ip_address}</span>
                        <span>{new Date(act.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                      <span className={`inline-block text-[9px] font-mono uppercase font-bold px-1.5 py-0.5 rounded border ${
                        isBooking
                          ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                          : isLogin
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : isCart
                          ? 'bg-purple-500/10 text-purple-400 border-purple-500/20'
                          : 'bg-sky-500/10 text-sky-400 border-sky-500/20'
                      }`}>
                        {act.page_url}
                      </span>
                      <p className="text-zinc-200 font-medium text-[11px] line-clamp-2">
                        {act.action}
                      </p>
                    </div>
                    <div className="pt-2 border-t border-white/5 flex items-center gap-1.5 text-[10px] text-zinc-400 truncate">
                      <Globe className="w-3 h-3 text-[#ff5a1f]" />
                      <span className="truncate">{browser.name}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* --- TAB 2: MANAGE MENU --- */}
      {activeTab === 'menu' && (
        <div className="space-y-6 animate-in fade-in duration-300">
          {/* Controls Bar */}
          <div className="bg-[#121212] border border-white/10 rounded-2xl p-4 sm:p-6 flex flex-col md:flex-row gap-4 items-center justify-between shadow-xl">
            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
              {['All', 'Veg', 'Non-Veg', 'Desserts', 'Drinks'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setMenuCategoryFilter(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                    menuCategoryFilter === cat
                      ? 'bg-[#ff5a1f] text-white'
                      : 'bg-black/50 text-zinc-400 hover:text-white'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3 w-full md:w-auto">
              <div className="relative flex-1 md:w-64">
                <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search dish..."
                  value={menuSearch}
                  onChange={(e) => setMenuSearch(e.target.value)}
                  className="w-full bg-black/50 border border-white/10 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff5a1f]"
                />
              </div>

              <button
                onClick={openCreateModal}
                className="px-4 py-2 rounded-xl bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 shadow-md shadow-[#ff5a1f]/20 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Item</span>
              </button>
            </div>
          </div>

          {/* Menu Table */}
          <div className="bg-[#121212] border border-white/10 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-zinc-300">
                <thead className="bg-black/60 border-b border-white/10 text-zinc-400 uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="py-3.5 px-4">Dish</th>
                    <th className="py-3.5 px-4">Category</th>
                    <th className="py-3.5 px-4">Price</th>
                    <th className="py-3.5 px-4">Signature</th>
                    <th className="py-3.5 px-4">Prep</th>
                    <th className="py-3.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredMenu.map((item) => (
                    <tr key={item.id} className="hover:bg-white/5 transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={item.image_url}
                            alt={item.name}
                            className="w-12 h-12 rounded-lg object-cover border border-white/10"
                          />
                          <div>
                            <span className="font-semibold text-white block text-sm">{item.name}</span>
                            <span className="text-[11px] text-zinc-400 line-clamp-1 max-w-xs">{item.description}</span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-full bg-black/60 border border-white/10 text-[10px] text-zinc-300">
                          {item.category}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-white text-sm">
                        ${item.price}
                      </td>
                      <td className="py-3 px-4">
                        {item.is_special ? (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#ff5a1f]/15 text-[#ff5a1f] font-semibold border border-[#ff5a1f]/30">
                            Chef Choice
                          </span>
                        ) : (
                          <span className="text-zinc-500">—</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-zinc-400 font-mono text-[11px]">
                        {item.prep_time || '20 min'}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => openEditModal(item)}
                            className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 transition-colors"
                            title="Edit Item"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteMenu(item.id, item.name)}
                            className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors"
                            title="Delete Item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* --- TAB 3: MANAGE BOOKINGS --- */}
      {activeTab === 'bookings' && (
        <div className="space-y-6 animate-in fade-in duration-300">
          {/* Booking Filters */}
          <div className="bg-[#121212] border border-white/10 rounded-2xl p-4 sm:p-6 flex flex-col md:flex-row gap-4 items-center justify-between shadow-xl">
            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
              {['all', 'pending', 'confirmed', 'rejected', 'completed'].map((status) => (
                <button
                  key={status}
                  onClick={() => setBookingStatusFilter(status)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                    bookingStatusFilter === status
                      ? 'bg-[#ff5a1f] text-white'
                      : 'bg-black/50 text-zinc-400 hover:text-white'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>

            <div className="relative w-full md:w-72">
              <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search guest, code, phone..."
                value={bookingSearch}
                onChange={(e) => setBookingSearch(e.target.value)}
                className="w-full bg-black/50 border border-white/10 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff5a1f]"
              />
            </div>
          </div>

          {/* Bookings Table */}
          <div className="bg-[#121212] border border-white/10 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-zinc-300">
                <thead className="bg-black/60 border-b border-white/10 text-zinc-400 uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="py-3.5 px-4">Code</th>
                    <th className="py-3.5 px-4">Guest Principal</th>
                    <th className="py-3.5 px-4">Contact</th>
                    <th className="py-3.5 px-4">Date & Time</th>
                    <th className="py-3.5 px-4">Party Size</th>
                    <th className="py-3.5 px-4">Seating</th>
                    <th className="py-3.5 px-4">Status</th>
                    <th className="py-3.5 px-4 text-right">Decision</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredBookings.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-zinc-500">
                        No bookings matching current criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredBookings.map((b) => (
                      <tr key={b.id} className="hover:bg-white/5 transition-colors">
                        <td className="py-3.5 px-4 font-mono font-bold text-[#ff5a1f]">
                          {b.id}
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="font-semibold text-white block text-sm">{b.name}</span>
                          {b.special_requests && (
                            <button
                              onClick={() => setSelectedBookingNotes(b)}
                              className="text-[11px] text-[#ff5a1f] underline mt-0.5 block hover:text-white"
                            >
                              View Guest Notes
                            </button>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-zinc-400">
                          <span className="block text-zinc-200">{b.phone}</span>
                          <span className="text-[11px] text-zinc-500">{b.email}</span>
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="font-semibold text-white block">{b.date}</span>
                          <span className="text-zinc-400 font-mono text-[11px]">{b.time}</span>
                        </td>
                        <td className="py-3.5 px-4 font-semibold text-white">
                          {b.guests} Guests
                        </td>
                        <td className="py-3.5 px-4 text-zinc-400">
                          {b.seating_preference || 'Main Hall'}
                        </td>
                        <td className="py-3.5 px-4">
                          <span className={`text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full ${
                            b.status === 'confirmed'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : b.status === 'rejected'
                              ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                              : b.status === 'completed'
                              ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                              : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          }`}>
                            {b.status}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {b.status !== 'confirmed' && (
                              <button
                                onClick={() => handleUpdateBookingStatus(b.id, 'confirmed')}
                                className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-semibold transition-colors cursor-pointer"
                                title="Accept & Confirm Reservation"
                              >
                                Accept
                              </button>
                            )}
                            {b.status !== 'rejected' && (
                              <button
                                onClick={() => handleUpdateBookingStatus(b.id, 'rejected')}
                                className="px-2.5 py-1 rounded bg-rose-600/80 hover:bg-rose-600 text-white text-[11px] font-semibold transition-colors cursor-pointer"
                                title="Reject Reservation"
                              >
                                Reject
                              </button>
                            )}
                            <button
                              onClick={() => handleDeleteBooking(b.id)}
                              className="p-1 rounded text-zinc-500 hover:text-rose-400"
                              title="Delete Record"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* --- TAB: PATRON & USER REGISTRATIONS --- */}
      {activeTab === 'users' && (
        <div className="space-y-6 animate-in fade-in duration-300">
          {/* Controls Bar */}
          <div className="bg-[#121212] border border-white/10 rounded-2xl p-4 sm:p-6 flex flex-col md:flex-row gap-4 items-center justify-between shadow-xl">
            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
              {[
                { id: 'all', label: 'All Patrons' },
                { id: 'vip_patron', label: 'VIP Patrons' },
                { id: 'member', label: 'Club Members' },
                { id: 'admin', label: 'Staff / Admin' }
              ].map((role) => (
                <button
                  key={role.id}
                  onClick={() => setUserRoleFilter(role.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                    userRoleFilter === role.id
                      ? 'bg-[#ff5a1f] text-white'
                      : 'bg-black/50 text-zinc-400 hover:text-white'
                  }`}
                >
                  {role.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3 w-full md:w-auto">
              <div className="relative flex-1 md:w-64">
                <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search user, email, ID..."
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  className="w-full bg-black/50 border border-white/10 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff5a1f]"
                />
              </div>

              <button
                onClick={() => setIsCreatingUser(true)}
                className="px-4 py-2 rounded-xl bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5 shadow-md shadow-[#ff5a1f]/20 cursor-pointer whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Register User</span>
              </button>

              <button
                onClick={handleResetUsers}
                className="p-2 rounded-xl bg-zinc-900 border border-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
                title="Reset mock users to default"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Users Table */}
          <div className="bg-[#121212] border border-white/10 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-zinc-300">
                <thead className="bg-black/60 border-b border-white/10 text-zinc-400 uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="py-3.5 px-4">Account ID</th>
                    <th className="py-3.5 px-4">Patron & Username</th>
                    <th className="py-3.5 px-4">Electronic Mail</th>
                    <th className="py-3.5 px-4">Telephone</th>
                    <th className="py-3.5 px-4">Role / Tier</th>
                    <th className="py-3.5 px-4">Registered Date</th>
                    <th className="py-3.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-12 text-center text-zinc-500">
                        No registered patron accounts found matching criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((u) => (
                      <tr key={u.id} className="hover:bg-white/5 transition-colors">
                        <td className="py-3.5 px-4 font-mono font-bold text-[#ff5a1f]">
                          {u.id}
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="font-semibold text-white block text-sm">{u.full_name || u.username}</span>
                          <span className="text-[11px] text-zinc-400 font-mono">@{u.username}</span>
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="text-zinc-200 font-mono text-xs">{u.email}</span>
                        </td>
                        <td className="py-3.5 px-4 text-zinc-400 font-mono">
                          {u.phone || '—'}
                        </td>
                        <td className="py-3.5 px-4">
                          <span className={`text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full ${
                            u.role === 'admin'
                              ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                              : u.role === 'vip_patron'
                              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                              : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          }`}>
                            {u.role.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-zinc-400 text-[11px] font-mono">
                          {new Date(u.registered_at).toLocaleDateString()}
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          {u.username !== 'kali' && (
                            <button
                              onClick={() => handleDeleteUser(u.id, u.username)}
                              className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors"
                              title="Delete user"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* --- TAB: ACTIVITY LOGS --- */}
      {activeTab === 'activity_logs' && (
        <div className="space-y-6 animate-in fade-in duration-300">
          {/* Header & Metric Banner */}
          <div className="bg-[#121212] border border-white/10 rounded-2xl p-6 shadow-xl space-y-6">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-white/10 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-serif-luxury font-bold text-white tracking-wide">
                    Live Activity Logs (Telemetry)
                  </h2>
                  <span className="px-2 py-0.5 rounded-full bg-[#ff5a1f]/10 text-[#ff5a1f] text-[10px] font-mono border border-[#ff5a1f]/20">
                    public.activity_logs
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-1">
                  Automatic telemetry logging for page visits, table reservations, authentication attempts, and shopping cart events.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleExportActivityCSV}
                  disabled={activityLogs.length === 0}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 hover:border-white/20 text-xs text-zinc-300 hover:text-white transition-colors cursor-pointer disabled:opacity-40"
                  title="Export activity logs as CSV"
                >
                  <Download className="w-3.5 h-3.5 text-[#ff5a1f]" />
                  <span>Export CSV</span>
                </button>

                <button
                  onClick={refreshData}
                  disabled={loadingData}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 hover:border-white/20 text-xs text-zinc-300 hover:text-white transition-colors cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 text-[#ff5a1f] ${loadingData ? 'animate-spin' : ''}`} />
                  <span>Refresh</span>
                </button>

                <button
                  onClick={handleClearActivityLogs}
                  disabled={activityLogs.length === 0}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500/20 text-xs text-rose-400 transition-colors cursor-pointer disabled:opacity-40"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear Activity Logs</span>
                </button>
              </div>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              <div className="p-3.5 rounded-xl bg-black/40 border border-white/5 space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-400">Total Events</span>
                <p className="text-xl font-bold font-mono text-white">{activityLogs.length}</p>
                <span className="text-[10px] text-zinc-500">All captured logs</span>
              </div>

              <div className="p-3.5 rounded-xl bg-black/40 border border-white/5 space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-400">Unique IPs</span>
                <p className="text-xl font-bold font-mono text-sky-400">{uniqueIpsCount}</p>
                <span className="text-[10px] text-zinc-500">Distinct visitor hosts</span>
              </div>

              <div className="p-3.5 rounded-xl bg-black/40 border border-white/5 space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-400">Page Views</span>
                <p className="text-xl font-bold font-mono text-emerald-400">{pageViewsCount}</p>
                <span className="text-[10px] text-zinc-500">Route impressions</span>
              </div>

              <div className="p-3.5 rounded-xl bg-black/40 border border-white/5 space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-400">Cart Actions</span>
                <p className="text-xl font-bold font-mono text-purple-400">{cartEventsCount}</p>
                <span className="text-[10px] text-zinc-500">Dishes added to order</span>
              </div>

              <div className="p-3.5 rounded-xl bg-black/40 border border-white/5 space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-400">Auth / Logins</span>
                <p className="text-xl font-bold font-mono text-[#ff5a1f]">{authEventsCount}</p>
                <span className="text-[10px] text-zinc-500">Sign in & patron joins</span>
              </div>
            </div>

            {/* Search & Category Filter Chips */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
              <div className="relative flex-1 max-w-md">
                <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Filter by IP, page URL, action, or browser..."
                  value={activitySearch}
                  onChange={(e) => setActivitySearch(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff5a1f]"
                />
              </div>

              <div className="flex flex-wrap items-center gap-1.5 bg-black/40 p-1 rounded-xl border border-white/5 text-xs">
                <button
                  onClick={() => setActivityActionFilter('all')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                    activityActionFilter === 'all'
                      ? 'bg-[#ff5a1f] text-white shadow-sm'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  All ({activityLogs.length})
                </button>
                <button
                  onClick={() => setActivityActionFilter('page_view')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                    activityActionFilter === 'page_view'
                      ? 'bg-sky-500 text-white shadow-sm'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Page Views ({pageViewsCount})
                </button>
                <button
                  onClick={() => setActivityActionFilter('booking')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                    activityActionFilter === 'booking'
                      ? 'bg-amber-500 text-white shadow-sm'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Bookings ({bookingEventsCount})
                </button>
                <button
                  onClick={() => setActivityActionFilter('login')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                    activityActionFilter === 'login'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Logins ({authEventsCount})
                </button>
                <button
                  onClick={() => setActivityActionFilter('cart')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                    activityActionFilter === 'cart'
                      ? 'bg-purple-600 text-white shadow-sm'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Cart ({cartEventsCount})
                </button>
              </div>
            </div>
          </div>

          {/* Activity Logs Table */}
          <div className="bg-[#121212] border border-white/10 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-zinc-300">
                <thead className="bg-black/60 border-b border-white/10 uppercase font-semibold text-[11px] text-zinc-400 tracking-wider">
                  <tr>
                    <th className="py-3.5 px-4 w-44">Time</th>
                    <th className="py-3.5 px-4 w-36">IP</th>
                    <th className="py-3.5 px-4 w-32">Page</th>
                    <th className="py-3.5 px-4">Action</th>
                    <th className="py-3.5 px-4 w-48">Browser</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredActivityLogs.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-zinc-500">
                        <Terminal className="w-8 h-8 mx-auto mb-2 text-zinc-600" />
                        <p className="font-medium">No activity records found matching criteria</p>
                        <p className="text-[11px] text-zinc-600 mt-1">
                          Try adjusting search keywords or clearing active filters
                        </p>
                      </td>
                    </tr>
                  ) : (
                    filteredActivityLogs.map((log) => {
                      const dateObj = new Date(log.created_at);
                      const timeStr = isNaN(dateObj.getTime())
                        ? log.created_at
                        : dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                      const dateStr = isNaN(dateObj.getTime())
                        ? ''
                        : dateObj.toLocaleDateString();

                      const isBooking = log.action.toUpperCase().includes('BOOKING');
                      const isLoginSuccess = log.action.toUpperCase().includes('LOGIN_SUCCESS') || log.action.toUpperCase().includes('REGISTRATION_SUCCESS');
                      const isLoginFailed = log.action.toUpperCase().includes('LOGIN_FAILED') || log.action.toUpperCase().includes('REGISTRATION_FAILED');
                      const isCart = log.action.toUpperCase().includes('CART');
                      const isPageView = log.action.toUpperCase().includes('PAGE_VIEW');

                      const browserInfo = parseBrowser(log.user_agent);

                      return (
                        <tr
                          key={log.id}
                          className="hover:bg-white/[0.02] transition-colors"
                        >
                          {/* Time */}
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <div className="font-mono text-zinc-200 font-semibold">{timeStr}</div>
                            <div className="text-[10px] text-zinc-500 font-mono">{dateStr}</div>
                          </td>

                          {/* IP */}
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <div className="inline-flex items-center gap-1.5 px-2 py-1 rounded-lg bg-black/60 border border-white/10 font-mono text-[11px] text-sky-400">
                              <span>{log.ip_address}</span>
                              <button
                                onClick={async () => {
                                  try {
                                    await navigator.clipboard.writeText(log.ip_address);
                                    setCopiedIp(log.id);
                                    setTimeout(() => setCopiedIp(null), 1500);
                                  } catch {
                                    // ignore
                                  }
                                }}
                                title="Copy IP"
                                className="text-zinc-500 hover:text-white cursor-pointer ml-0.5"
                              >
                                {copiedIp === log.id ? (
                                  <Check className="w-3 h-3 text-emerald-400" />
                                ) : (
                                  <Copy className="w-3 h-3" />
                                )}
                              </button>
                            </div>
                          </td>

                          {/* Page */}
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <span className="font-mono text-[11px] px-2 py-0.5 rounded-md bg-zinc-900 border border-white/10 text-zinc-300">
                              {log.page_url}
                            </span>
                          </td>

                          {/* Action */}
                          <td className="py-3.5 px-4">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span
                                  className={`text-[9px] font-mono uppercase font-bold px-1.5 py-0.5 rounded border ${
                                    isBooking
                                      ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                                      : isLoginSuccess
                                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                                      : isLoginFailed
                                      ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                                      : isCart
                                      ? 'bg-purple-500/10 text-purple-400 border-purple-500/20'
                                      : isPageView
                                      ? 'bg-sky-500/10 text-sky-400 border-sky-500/20'
                                      : 'bg-zinc-800 text-zinc-300 border-zinc-700'
                                  }`}
                                >
                                  {isBooking
                                    ? 'BOOKING'
                                    : isLoginSuccess
                                    ? 'AUTH SUCCESS'
                                    : isLoginFailed
                                    ? 'AUTH FAILED'
                                    : isCart
                                    ? 'CART'
                                    : isPageView
                                    ? 'PAGE VIEW'
                                    : 'EVENT'}
                                </span>
                              </div>
                              <p className="text-xs text-zinc-200 font-medium break-words">
                                {log.action}
                              </p>
                            </div>
                          </td>

                          {/* Browser */}
                          <td className="py-3.5 px-4">
                            <div
                              className="cursor-help"
                              title={log.user_agent}
                            >
                              <div className="flex items-center gap-1.5 text-zinc-200 font-medium">
                                <Globe className="w-3.5 h-3.5 text-[#ff5a1f] flex-shrink-0" />
                                <span className="truncate max-w-[180px]">{browserInfo.name}</span>
                              </div>
                              <div className="text-[10px] text-zinc-500 font-mono truncate max-w-[180px] mt-0.5">
                                {log.user_agent}
                              </div>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Table Footer */}
            <div className="p-4 bg-black/60 border-t border-white/10 flex items-center justify-between text-xs text-zinc-400">
              <span>
                Showing {filteredActivityLogs.length} of {activityLogs.length} activity records
              </span>
              <span className="text-[11px] text-zinc-500 font-mono">
                Auto-synced with Supabase public.activity_logs
              </span>
            </div>
          </div>
        </div>
      )}

      {/* --- TAB 4: ACTION AUDIT LOGS --- */}
      {activeTab === 'logs' && (
        <div className="space-y-6 animate-in fade-in duration-300">
          <div className="bg-[#121212] border border-white/10 rounded-2xl p-4 sm:p-6 flex items-center justify-between shadow-xl">
            <div>
              <h2 className="text-sm font-semibold text-white uppercase tracking-wider">
                System Security & Concierge Audit Trail
              </h2>
              <p className="text-xs text-zinc-400">
                Immutable chronological log of all administrative actions, table approvals, and menu updates.
              </p>
            </div>
            <button
              onClick={handleClearLogs}
              className="px-3 py-1.5 rounded-xl bg-zinc-900 border border-white/10 text-xs text-zinc-400 hover:text-white transition-colors cursor-pointer"
            >
              Clear Logs
            </button>
          </div>

          <div className="bg-[#121212] border border-white/10 rounded-2xl p-6 shadow-xl space-y-3">
            {logs.map((log) => (
              <div
                key={log.id}
                className="p-3.5 rounded-xl bg-black/40 border border-white/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-zinc-800 text-[#ff5a1f] font-semibold">
                      {log.action}
                    </span>
                    <span className="text-[11px] text-zinc-400">Actor: {log.user}</span>
                  </div>
                  <p className="text-zinc-200">{log.details}</p>
                </div>
                <span className="text-[11px] font-mono text-zinc-500 whitespace-nowrap">
                  {new Date(log.timestamp).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* --- TAB 5: DATABASE & SUPABASE SETTINGS --- */}
      {activeTab === 'database' && (
        <div className="space-y-6 animate-in fade-in duration-300">
          <div className="bg-[#121212] border border-white/10 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <h2 className="text-base font-semibold text-white">PostgreSQL & Supabase Architecture</h2>
                <p className="text-xs text-zinc-400">
                  Dual-tier database layer with seamless LocalStorage fallback and native Supabase integration.
                </p>
              </div>
              <button
                onClick={onOpenSQLModal}
                className="px-4 py-2 rounded-xl bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-semibold cursor-pointer"
              >
                Configure Supabase Connection
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-black/50 border border-white/10 space-y-1">
                <span className="text-zinc-500 block">Table 1</span>
                <span className="font-mono text-white font-bold block">public.menu_items</span>
                <p className="text-[11px] text-zinc-400">id, name, description, price, category, image_url, is_special</p>
              </div>
              <div className="p-4 rounded-xl bg-black/50 border border-white/10 space-y-1">
                <span className="text-zinc-500 block">Table 2</span>
                <span className="font-mono text-white font-bold block">public.bookings</span>
                <p className="text-[11px] text-zinc-400">id, name, phone, email, date, time, guests, status, created_at</p>
              </div>
              <div className="p-4 rounded-xl bg-black/50 border border-white/10 space-y-1">
                <span className="text-zinc-500 block">Table 3</span>
                <span className="font-mono text-white font-bold block">public.users</span>
                <p className="text-[11px] text-zinc-400">id, username, email, full_name, password_hash, role</p>
              </div>
              <div className="p-4 rounded-xl bg-black/50 border border-white/10 space-y-1">
                <span className="text-zinc-500 block">Table 4 (Activity Logs)</span>
                <span className="font-mono text-sky-400 font-bold block">public.activity_logs</span>
                <p className="text-[11px] text-zinc-400">id, ip_address, page_url, action, user_agent, created_at</p>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={async () => {
                  try {
                    await navigator.clipboard.writeText(dbService.getSQLSchema());
                    setCopiedSQL(true);
                    setTimeout(() => setCopiedSQL(false), 2000);
                  } catch {
                    // ignore
                  }
                }}
                className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer"
              >
                {copiedSQL ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSQL ? 'SQL Copied!' : 'Copy Complete Supabase SQL Script'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- ADD / EDIT MENU MODAL --- */}
      {(isCreatingMenu || isEditingMenu) && (
        <div
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => {
            setIsCreatingMenu(false);
            setIsEditingMenu(null);
          }}
        >
          <div
            className="relative max-w-lg w-full bg-[#121212] border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl text-white space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-lg font-serif-luxury font-bold text-white">
              {isEditingMenu ? 'Edit Menu Creation' : 'Add New Menu Creation'}
            </h3>

            <form onSubmit={handleSaveMenu} className="space-y-4 text-xs">
              <div>
                <label className="block text-zinc-400 mb-1">Dish Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Hokkaido Scallop Carpaccio"
                  value={menuForm.name}
                  onChange={(e) => setMenuForm({ ...menuForm, name: e.target.value })}
                  className="w-full bg-black/60 border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-[#ff5a1f]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-400 mb-1">Category *</label>
                  <select
                    value={menuForm.category}
                    onChange={(e) => setMenuForm({ ...menuForm, category: e.target.value as MenuCategory })}
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#ff5a1f]"
                  >
                    <option value="Veg">Veg</option>
                    <option value="Non-Veg">Non-Veg</option>
                    <option value="Desserts">Desserts</option>
                    <option value="Drinks">Drinks</option>
                  </select>
                </div>
                <div>
                  <label className="block text-zinc-400 mb-1">Price ($ USD) *</label>
                  <input
                    type="number"
                    min="1"
                    step="0.5"
                    required
                    value={menuForm.price}
                    onChange={(e) => setMenuForm({ ...menuForm, price: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-[#ff5a1f]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-zinc-400 mb-1">Description *</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Heirloom ingredients, cooking technique, and tasting notes..."
                  value={menuForm.description}
                  onChange={(e) => setMenuForm({ ...menuForm, description: e.target.value })}
                  className="w-full bg-black/60 border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-[#ff5a1f] resize-none"
                />
              </div>

              <div>
                <label className="block text-zinc-400 mb-1">Image URL *</label>
                <input
                  type="url"
                  required
                  placeholder="https://images.unsplash.com/..."
                  value={menuForm.image_url}
                  onChange={(e) => setMenuForm({ ...menuForm, image_url: e.target.value })}
                  className="w-full bg-black/60 border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-[#ff5a1f]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-400 mb-1">Estimated Preparation Time</label>
                  <input
                    type="text"
                    value={menuForm.prep_time}
                    onChange={(e) => setMenuForm({ ...menuForm, prep_time: e.target.value })}
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-[#ff5a1f]"
                  />
                </div>
                <div>
                  <label className="block text-zinc-400 mb-1">Calories (kcal)</label>
                  <input
                    type="number"
                    value={menuForm.calories}
                    onChange={(e) => setMenuForm({ ...menuForm, calories: parseInt(e.target.value) || 0 })}
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-[#ff5a1f]"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="is_special"
                  checked={menuForm.is_special}
                  onChange={(e) => setMenuForm({ ...menuForm, is_special: e.target.checked })}
                  className="accent-[#ff5a1f] w-4 h-4 rounded"
                />
                <label htmlFor="is_special" className="text-zinc-200 font-medium cursor-pointer">
                  Featured Chef's Signature Special
                </label>
              </div>

              <div className="flex gap-2 pt-4 border-t border-white/10">
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-[#ff5a1f] hover:bg-[#e04b14] text-white font-semibold transition-colors cursor-pointer"
                >
                  {isEditingMenu ? 'Update Dish' : 'Create Dish'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsCreatingMenu(false);
                    setIsEditingMenu(null);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-medium transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- GUEST NOTES MODAL --- */}
      {selectedBookingNotes && (
        <div
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setSelectedBookingNotes(null)}
        >
          <div
            className="max-w-md w-full bg-[#121212] border border-white/15 rounded-2xl p-6 text-white space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-base font-semibold text-white">
              Notes for {selectedBookingNotes.name} ({selectedBookingNotes.id})
            </h3>
            <div className="p-4 rounded-xl bg-black/50 border border-white/10 text-xs text-zinc-300">
              "{selectedBookingNotes.special_requests}"
            </div>
            <div className="flex justify-end">
              <button
                onClick={() => setSelectedBookingNotes(null)}
                className="px-4 py-2 rounded-lg bg-zinc-800 text-white text-xs hover:bg-zinc-700"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- REGISTER USER / PATRON MODAL --- */}
      {isCreatingUser && (
        <div
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setIsCreatingUser(false)}
        >
          <div
            className="relative max-w-lg w-full bg-[#121212] border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl text-white space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <h3 className="text-lg font-serif-luxury font-bold text-white">
                  Register New Patron / Account
                </h3>
                <p className="text-xs text-zinc-400">Add user credentials and access tier to the database</p>
              </div>
              <button
                onClick={() => setIsCreatingUser(false)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-white/5"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveUser} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-400 mb-1">Username *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. alex_wright"
                    value={userForm.username}
                    onChange={(e) => setUserForm({ ...userForm, username: e.target.value })}
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-[#ff5a1f]"
                  />
                </div>
                <div>
                  <label className="block text-zinc-400 mb-1">Full Legal Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Alexander Wright"
                    value={userForm.full_name}
                    onChange={(e) => setUserForm({ ...userForm, full_name: e.target.value })}
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-[#ff5a1f]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-zinc-400 mb-1">Electronic Mail (E-mail) *</label>
                <input
                  type="email"
                  required
                  placeholder="name@domain.com"
                  value={userForm.email}
                  onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
                  className="w-full bg-black/60 border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-[#ff5a1f]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-400 mb-1">Role / Membership Tier *</label>
                  <select
                    value={userForm.role}
                    onChange={(e) => setUserForm({ ...userForm, role: e.target.value as UserRole })}
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-[#ff5a1f]"
                  >
                    <option value="member">Club Member</option>
                    <option value="vip_patron">VIP Patron</option>
                    <option value="admin">Staff / Admin</option>
                  </select>
                </div>
                <div>
                  <label className="block text-zinc-400 mb-1">Contact Telephone</label>
                  <input
                    type="tel"
                    placeholder="+1 (555) 000-0000"
                    value={userForm.phone}
                    onChange={(e) => setUserForm({ ...userForm, phone: e.target.value })}
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-[#ff5a1f]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-zinc-400 mb-1">Access Password *</label>
                <input
                  type="password"
                  required
                  placeholder="Set account password"
                  value={userForm.password}
                  onChange={(e) => setUserForm({ ...userForm, password: e.target.value })}
                  className="w-full bg-black/60 border border-white/10 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-[#ff5a1f] font-mono"
                />
              </div>

              <div className="flex gap-2 pt-3 border-t border-white/10">
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-[#ff5a1f] hover:bg-[#e04b14] text-white font-semibold transition-colors cursor-pointer"
                >
                  Create & Register User
                </button>
                <button
                  type="button"
                  onClick={() => setIsCreatingUser(false)}
                  className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-medium transition-colors cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
