import React from 'react';
import { Flame, Award, Wine, Sparkles, Compass, ArrowRight, ShieldCheck, Heart } from 'lucide-react';

interface ChefPageProps {
  onSelectTab: (tab: string) => void;
}

export const ChefPage: React.FC<ChefPageProps> = ({ onSelectTab }) => {
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-20">
      {/* Intro Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-[#ff5a1f] uppercase tracking-widest font-semibold">
          <Flame className="w-3.5 h-3.5" />
          <span>Atelier Heritage</span>
        </div>
        <h1 className="text-4xl sm:text-6xl font-serif-luxury font-bold text-white tracking-tight">
          The Story of kali
        </h1>
        <p className="text-sm text-zinc-400 font-light leading-relaxed">
          Born from an obsession with elemental heat, heirloom botany, and the disciplined refinement of classical French and Japanese culinary arts.
        </p>
      </div>

      {/* Main Chef Spotlight */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div className="relative">
          <div className="aspect-[4/5] rounded-3xl overflow-hidden border border-white/15 shadow-2xl relative">
            <img
              src="https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=1200&q=80"
              alt="Executive Chef Marco Kali"
              className="w-full h-full object-cover filter brightness-95 contrast-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            <div className="absolute bottom-6 left-6 right-6">
              <span className="text-xs font-mono uppercase text-[#ff5a1f] tracking-widest block mb-1">
                Executive Chef & Founder
              </span>
              <h3 className="text-3xl font-serif-luxury font-bold text-white">Chef Marco Kali</h3>
              <p className="text-xs text-zinc-300 mt-1">20 Years of Gastronomic Mastery across Paris, Kyoto & New York</p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <span className="text-xs font-semibold text-[#ff5a1f] tracking-widest uppercase">
            A Journey of Discipline
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-white leading-tight">
            "We do not mask the essence of an ingredient. We reveal its soul through flame."
          </h2>

          <p className="text-zinc-300 text-sm leading-relaxed">
            Raised between the olive groves of Tuscany and the classic kitchens of Paris, Chef Marco apprenticed under legendary Michelin tri-star masters before spending four formative years in Kyoto studying the art of Kaiseki and binchotan wood grilling.
          </p>

          <p className="text-zinc-400 text-xs leading-relaxed">
            In 2021, he founded <strong className="text-white">kali</strong> with a simple yet audacious ambition: to strip away frivolous theatrical garnishes and return to the primordial magic of fire, wood, wild fermentation, and impeccable seasonal harvesting.
          </p>

          <div className="space-y-3 pt-4 border-t border-white/10">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#ff5a1f]/10 flex items-center justify-center text-[#ff5a1f] flex-shrink-0">
                <Flame className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-semibold text-white uppercase tracking-wider">Kishu Binchotan Charcoal</h4>
                <p className="text-xs text-zinc-400">White charcoal sourced from Wakayama, burning odorless and smokeless at 1,000°C for searing perfection.</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#ff5a1f]/10 flex items-center justify-center text-[#ff5a1f] flex-shrink-0">
                <Compass className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-semibold text-white uppercase tracking-wider">Wild Micro-Foraging</h4>
                <p className="text-xs text-zinc-400">Collaborating with trusted foragers for seasonal pine needles, wild morels, mountain sorrel, and sea truffles.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Sommelier & Cellar Spotlight */}
      <div className="bg-[#121212] border border-white/10 rounded-3xl p-8 sm:p-14 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6 order-2 lg:order-1">
          <span className="text-xs font-semibold text-[#ff5a1f] tracking-widest uppercase flex items-center gap-2">
            <Wine className="w-4 h-4" />
            <span>The Cellar Sanctuary</span>
          </span>

          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-white leading-tight">
            Curated by Master Sommelier Elena Vance
          </h2>

          <p className="text-zinc-300 text-sm leading-relaxed">
            Housed beneath the dining salon rests our 400-bottle temperature and humidity-controlled subterranean vault. Elena leads our beverage program with a focus on rare estate Burgundies, biodynamic grower Champagnes, and small-batch Japanese whiskies.
          </p>

          <blockquote className="p-4 bg-black/40 rounded-2xl border-l-2 border-[#ff5a1f] text-xs text-zinc-300 italic">
            "Every pairing is conceived as a dialogue between temperature, tannin, and the embers of the kitchen."
          </blockquote>

          <div className="flex gap-4 pt-2">
            <button
              onClick={() => onSelectTab('menu')}
              className="px-6 py-3 rounded-full bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer"
            >
              Discover Wine & Spirits
            </button>
            <button
              onClick={() => onSelectTab('book')}
              className="px-6 py-3 rounded-full bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer"
            >
              Book Tasting Session
            </button>
          </div>
        </div>

        <div className="aspect-[4/3] rounded-2xl overflow-hidden border border-white/10 relative order-1 lg:order-2">
          <img
            src="https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=1200&q=80"
            alt="The Wine Cellar Vault"
            className="w-full h-full object-cover filter contrast-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
          <div className="absolute bottom-6 left-6">
            <span className="text-xs font-bold text-white uppercase tracking-wider block">Subterranean Vault</span>
            <span className="text-[11px] text-zinc-400">Grand Cru, Premier Cru, and Natural Cellar</span>
          </div>
        </div>
      </div>
    </div>
  );
};
