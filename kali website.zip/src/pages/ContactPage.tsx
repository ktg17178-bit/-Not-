import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle2, Shield, Car, Sparkles } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'Private Dining Inquiry',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-[#ff5a1f] uppercase tracking-widest font-semibold">
          <Mail className="w-3.5 h-3.5" />
          <span>Atelier Concierge</span>
        </div>
        <h1 className="text-4xl sm:text-6xl font-serif-luxury font-bold text-white tracking-tight">
          Connect with kali
        </h1>
        <p className="text-sm text-zinc-400 font-light leading-relaxed">
          For private dining buyouts, wedding receptions, cellar inquiries, or tailored corporate events, our senior hospitality team is at your disposal.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Contact Information & Hours */}
        <div className="space-y-8">
          <div className="bg-[#121212] border border-white/10 rounded-3xl p-8 space-y-6">
            <h3 className="text-xl font-serif-luxury font-bold text-white">
              Location & Valet Service
            </h3>

            <div className="space-y-4 text-xs text-zinc-300">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[#ff5a1f] mt-1 flex-shrink-0" />
                <div>
                  <span className="font-semibold text-white block">Atelier Address</span>
                  <span>142 Regent Boulevard, Suite 500, Fine Arts District</span>
                  <span className="block text-zinc-500 text-[11px] mt-0.5">Complimentary white-glove valet parking at main portico</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-[#ff5a1f] mt-1 flex-shrink-0" />
                <div>
                  <span className="font-semibold text-white block">Concierge Telephone</span>
                  <span>+1 (555) 794-KALI (5254)</span>
                  <span className="block text-zinc-500 text-[11px] mt-0.5">Available Tuesday through Sunday from 10:00 AM</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-[#ff5a1f] mt-1 flex-shrink-0" />
                <div>
                  <span className="font-semibold text-white block">Electronic Correspondence</span>
                  <span>reservations@kali-restaurant.com</span>
                  <span className="block text-zinc-500 text-[11px] mt-0.5">Press & Events: atelier@kali-restaurant.com</span>
                </div>
              </div>
            </div>
          </div>

          {/* Service Hours */}
          <div className="bg-[#121212] border border-white/10 rounded-3xl p-8 space-y-4">
            <div className="flex items-center gap-2 text-[#ff5a1f]">
              <Clock className="w-4 h-4" />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-white">Service Schedules</h3>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs text-zinc-400">
              <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
                <span className="text-zinc-200 font-semibold block">Lunch Tasting</span>
                <p>Tue – Fri: 12:00 PM – 2:45 PM</p>
                <p className="text-[11px] text-zinc-500">4-course or 6-course discovery</p>
              </div>

              <div className="p-3 bg-black/40 rounded-xl border border-white/5 space-y-1">
                <span className="text-zinc-200 font-semibold block">Grand Dinner Tasting</span>
                <p>Tue – Sun: 6:00 PM – 11:30 PM</p>
                <p className="text-[11px] text-zinc-500">8-course signature culinary journey</p>
              </div>
            </div>
          </div>
        </div>

        {/* Interactive Inquiry Form */}
        <div className="bg-[#121212] border border-white/10 rounded-3xl p-8 sm:p-10 shadow-xl">
          {submitted ? (
            <div className="text-center py-12 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#ff5a1f]/15 border border-[#ff5a1f]/40 flex items-center justify-center text-[#ff5a1f] mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-serif-luxury font-bold text-white">
                Message Received
              </h3>
              <p className="text-xs text-zinc-400 max-w-sm mx-auto">
                Thank you for contacting kali. Our guest experience director will respond to your correspondence within 24 hours.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="mt-4 px-6 py-2.5 rounded-full bg-zinc-800 text-white text-xs hover:bg-zinc-700 transition-colors"
              >
                Send Another Inquiry
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <h3 className="text-xl font-serif-luxury font-bold text-white mb-2">
                Send an Inquiry
              </h3>

              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1">Your Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Elena Rostova"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#ff5a1f]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="elena@domain.com"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#ff5a1f]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    placeholder="+1 (555) 000-0000"
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#ff5a1f]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1">Inquiry Nature</label>
                <select
                  value={form.subject}
                  onChange={(e) => setForm({ ...form, subject: e.target.value })}
                  className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-[#ff5a1f]"
                >
                  <option value="Private Dining Inquiry">Private Dining & Salon Buyout</option>
                  <option value="Sommelier & Wine Vault Consultation">Sommelier & Wine Vault Consultation</option>
                  <option value="Press & Media Accreditation">Press & Media Accreditation</option>
                  <option value="Special Dietary Arrangement">Special Dietary Arrangement</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1">Message & Specific Requirements</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Please specify estimated guest counts, desired dates, or dietary requests..."
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-[#ff5a1f] resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 px-6 rounded-xl bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-bold uppercase tracking-wider transition-all shadow-lg shadow-[#ff5a1f]/20 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Transmit Inquiry</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
