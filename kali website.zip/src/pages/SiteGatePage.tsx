import React, { useState, useEffect } from 'react';
import { dbService, AuthenticatedUser } from '../services/db';
import { logActivity } from '../services/logger';
import {
  Lock,
  User,
  Eye,
  EyeOff,
  ShieldCheck,
  ArrowRight,
  AlertCircle,
  KeyRound,
  Mail,
  UserPlus,
  CheckCircle2,
  Phone,
  Sparkles,
  Hash
} from 'lucide-react';

interface SiteGatePageProps {
  onUnlock: (user: AuthenticatedUser) => void;
}

export const SiteGatePage: React.FC<SiteGatePageProps> = ({ onUnlock }) => {
  const [gateMode, setGateMode] = useState<'signin' | 'register'>('signin');

  // Log page visit on mount
  useEffect(() => {
    logActivity('PAGE_VIEW: SECURITY_GATE', '/login');
  }, []);

  // Sign In States
  const [signInIdentifier, setSignInIdentifier] = useState('');
  const [signInPassword, setSignInPassword] = useState('');
  const [showSignInPassword, setShowSignInPassword] = useState(false);

  // Registration States
  const [regFullName, setRegFullName] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);

  // Feedback States
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [registrationSuccess, setRegistrationSuccess] = useState<{
    id: string;
    username: string;
    email: string;
    fullName: string;
    authUser: AuthenticatedUser;
  } | null>(null);

  // Handle Sign In
  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!signInIdentifier.trim() || !signInPassword.trim()) {
      setError('Please provide your username or email and password.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const cleanIdent = signInIdentifier.trim().toLowerCase();
      const cleanPass = signInPassword.trim();

      const result = await dbService.authenticateUser(cleanIdent, cleanPass);
      if (result.success && result.user) {
        logActivity(`LOGIN_SUCCESS: Patron "${cleanIdent}" authenticated`, '/login');
        onUnlock(result.user);
      } else {
        const errorMsg = result.error || 'Invalid credentials. Access denied.';
        logActivity(`LOGIN_FAILED: Access denied for "${cleanIdent}"`, '/login');
        setError(errorMsg);
      }
    } catch {
      logActivity(`LOGIN_FAILED: Error during authentication for "${signInIdentifier.trim()}"`, '/login');
      setError('Authentication failed. Please verify credentials.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Registration into Database
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!regFullName.trim()) {
      setError('Please provide your full legal or preferred patron name.');
      return;
    }
    if (!regUsername.trim()) {
      setError('Please choose a username.');
      return;
    }
    if (!regEmail.trim() || !regEmail.includes('@') || !regEmail.includes('.')) {
      setError('Please provide a valid electronic mail address.');
      return;
    }
    if (regPassword.length < 4) {
      setError('Password must contain at least 4 characters.');
      return;
    }
    if (regPassword !== regConfirmPassword) {
      setError('Passwords do not match. Please re-enter.');
      return;
    }

    setIsSubmitting(true);

    try {
      const regResult = await dbService.registerUser({
        full_name: regFullName.trim(),
        username: regUsername.trim(),
        email: regEmail.trim(),
        passwordPlain: regPassword.trim(),
        phone: regPhone.trim() || undefined,
        role: 'member'
      });

      if (regResult.success && regResult.user && regResult.authUser) {
        logActivity(`REGISTRATION_SUCCESS: New patron "${regResult.user.username}" (${regResult.user.email}) registered`, '/login#register');
        setRegistrationSuccess({
          id: regResult.user.id,
          username: regResult.user.username,
          email: regResult.user.email,
          fullName: regResult.user.full_name,
          authUser: regResult.authUser
        });
      } else {
        const errorMsg = regResult.error || 'Failed to complete registration.';
        logActivity(`REGISTRATION_FAILED: Registration rejected for "${regUsername.trim()}": ${errorMsg}`, '/login#register');
        setError(errorMsg);
      }
    } catch {
      logActivity(`REGISTRATION_FAILED: Database error during registration for "${regUsername.trim()}"`, '/login#register');
      setError('Registration error. Could not record to database.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#070707] text-white flex flex-col justify-between relative overflow-hidden select-none">
      {/* Background Ambience */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <img
          src="https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=2000&q=85"
          alt="kali Luxury Interior"
          className="w-full h-full object-cover opacity-25 filter brightness-50 contrast-125 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#070707] via-[#070707]/90 to-[#070707]/70" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#ff5a1f]/10 rounded-full blur-[140px]" />
      </div>

      {/* Top Header */}
      <header className="relative z-10 p-6 sm:p-8 flex items-center justify-between border-b border-white/5">
        <div className="flex items-center gap-2">
          <span className="text-2xl font-serif-luxury font-bold tracking-widest text-white flex items-center">
            kali
            <span className="w-1.5 h-1.5 rounded-full bg-[#ff5a1f] ml-1 mt-1.5 inline-block"></span>
          </span>
          <span className="text-[9px] uppercase tracking-[0.25em] text-zinc-500 font-medium pl-2 border-l border-white/10 hidden sm:inline-block">
            Haute Cuisine & Cocktails
          </span>
        </div>

        <div className="flex items-center gap-2 text-[11px] text-zinc-400 font-mono bg-black/60 px-3.5 py-1 rounded-full border border-white/10">
          <Lock className="w-3 h-3 text-[#ff5a1f]" />
          <span>Restricted Private Access</span>
        </div>
      </header>

      {/* Center Gate Form */}
      <main className="relative z-10 flex-1 flex items-center justify-center p-4 sm:p-6 my-auto">
        <div className="w-full max-w-md bg-[#111111]/95 border border-white/15 rounded-3xl p-6 sm:p-9 shadow-2xl backdrop-blur-xl space-y-6">
          {/* Header Emblem */}
          <div className="text-center space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-b from-[#ff5a1f]/20 to-[#ff5a1f]/5 border border-[#ff5a1f]/35 flex items-center justify-center text-[#ff5a1f] mx-auto shadow-lg shadow-[#ff5a1f]/10">
              {gateMode === 'signin' ? (
                <KeyRound className="w-7 h-7" />
              ) : (
                <UserPlus className="w-7 h-7" />
              )}
            </div>

            <div className="space-y-1">
              <span className="text-[10px] uppercase tracking-[0.3em] text-[#ff5a1f] font-semibold block">
                {gateMode === 'signin' ? 'Restricted Private Atelier' : 'Patron Member Database'}
              </span>
              <h1 className="text-2xl sm:text-3xl font-serif-luxury font-bold text-white tracking-tight">
                {gateMode === 'signin' ? 'Patron & Staff Verification' : 'Patron Account Registration'}
              </h1>
              <p className="text-xs text-zinc-400 max-w-xs mx-auto leading-relaxed">
                {gateMode === 'signin'
                  ? 'Please provide your authorized credentials or email to enter kali atelier.'
                  : 'Register your profile into the database to receive an assigned Patron ID.'}
              </p>
            </div>
          </div>

          {/* Mode Tabs */}
          {!registrationSuccess && (
            <div className="grid grid-cols-2 p-1 bg-black/60 rounded-xl border border-white/10">
              <button
                type="button"
                onClick={() => {
                  setGateMode('signin');
                  setError(null);
                }}
                className={`py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  gateMode === 'signin'
                    ? 'bg-[#ff5a1f] text-white shadow-md'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setGateMode('register');
                  setError(null);
                }}
                className={`py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  gateMode === 'register'
                    ? 'bg-[#ff5a1f] text-white shadow-md'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Register Patron
              </button>
            </div>
          )}

          {/* Error Banner */}
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2.5 animate-in fade-in duration-200">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* REGISTRATION SUCCESS RECEIPT */}
          {registrationSuccess ? (
            <div className="bg-black/70 border border-[#ff5a1f]/40 rounded-2xl p-5 space-y-4 animate-in zoom-in-95 duration-200">
              <div className="flex items-center gap-2.5 text-emerald-400">
                <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                <span className="text-xs font-bold uppercase tracking-wider">
                  Registration Confirmed in Database
                </span>
              </div>

              <div className="space-y-2 text-xs bg-zinc-900/80 p-3.5 rounded-xl border border-white/10 font-mono">
                <div className="flex justify-between items-center text-zinc-400">
                  <span>Assigned Account ID:</span>
                  <span className="text-[#ff5a1f] font-bold text-sm">{registrationSuccess.id}</span>
                </div>
                <div className="flex justify-between items-center text-zinc-400">
                  <span>Patron Name:</span>
                  <span className="text-white font-sans">{registrationSuccess.fullName}</span>
                </div>
                <div className="flex justify-between items-center text-zinc-400">
                  <span>Username:</span>
                  <span className="text-zinc-200">@{registrationSuccess.username}</span>
                </div>
                <div className="flex justify-between items-center text-zinc-400">
                  <span>Electronic Mail:</span>
                  <span className="text-zinc-200">{registrationSuccess.email}</span>
                </div>
                <div className="flex justify-between items-center text-zinc-400 pt-1 border-t border-white/5">
                  <span>Access Status:</span>
                  <span className="text-emerald-400 uppercase text-[10px] font-bold">Authorized & Active</span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => onUnlock(registrationSuccess.authUser)}
                className="w-full py-3.5 px-6 rounded-xl bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-bold tracking-widest uppercase transition-all shadow-xl shadow-[#ff5a1f]/25 flex items-center justify-center gap-2 cursor-pointer group"
              >
                <Sparkles className="w-4 h-4" />
                <span>Enter kali Atelier Now</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          ) : gateMode === 'signin' ? (
            /* --- SIGN IN FORM --- */
            <form onSubmit={handleSignIn} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-[#ff5a1f]" />
                  Username or Registered Email
                </label>
                <input
                  type="text"
                  required
                  autoFocus
                  autoComplete="off"
                  placeholder="Enter username or email address"
                  value={signInIdentifier}
                  onChange={(e) => setSignInIdentifier(e.target.value)}
                  className="w-full bg-black/70 border border-white/10 focus:border-[#ff5a1f] rounded-xl px-4 py-3 text-xs text-white placeholder-zinc-600 focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-[#ff5a1f]" />
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showSignInPassword ? 'text' : 'password'}
                    required
                    autoComplete="off"
                    placeholder="Enter your password"
                    value={signInPassword}
                    onChange={(e) => setSignInPassword(e.target.value)}
                    className="w-full bg-black/70 border border-white/10 focus:border-[#ff5a1f] rounded-xl px-4 py-3 pr-10 text-xs text-white placeholder-zinc-600 focus:outline-none font-mono transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowSignInPassword(!showSignInPassword)}
                    className="absolute right-3 top-3 text-zinc-500 hover:text-white transition-colors p-0.5 cursor-pointer"
                    tabIndex={-1}
                  >
                    {showSignInPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 px-6 rounded-xl bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-bold tracking-widest uppercase transition-all shadow-xl shadow-[#ff5a1f]/25 flex items-center justify-center gap-2 group cursor-pointer disabled:opacity-50 mt-2"
              >
                {isSubmitting ? (
                  <span>Verifying Credentials...</span>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Enter kali Atelier</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </button>
            </form>
          ) : (
            /* --- REGISTRATION FORM --- */
            <form onSubmit={handleRegister} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-medium text-zinc-300 mb-1 flex items-center gap-1.5">
                  <User className="w-3 h-3 text-[#ff5a1f]" />
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Lord Arthur Sterling"
                  value={regFullName}
                  onChange={(e) => setRegFullName(e.target.value)}
                  className="w-full bg-black/70 border border-white/10 focus:border-[#ff5a1f] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none transition-colors"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-zinc-300 mb-1 flex items-center gap-1.5">
                    <Hash className="w-3 h-3 text-[#ff5a1f]" />
                    Username
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. arthur_sterling"
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '_'))}
                    className="w-full bg-black/70 border border-white/10 focus:border-[#ff5a1f] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none font-mono transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-zinc-300 mb-1 flex items-center gap-1.5">
                    <Mail className="w-3 h-3 text-[#ff5a1f]" />
                    Email
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="e.g. arthur@luxury.com"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="w-full bg-black/70 border border-white/10 focus:border-[#ff5a1f] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-zinc-300 mb-1 flex items-center gap-1.5">
                  <Phone className="w-3 h-3 text-[#ff5a1f]" />
                  Telephone (Optional)
                </label>
                <input
                  type="tel"
                  placeholder="e.g. +1 (555) 234-5678"
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  className="w-full bg-black/70 border border-white/10 focus:border-[#ff5a1f] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none transition-colors font-mono"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-zinc-300 mb-1 flex items-center gap-1.5">
                    <Lock className="w-3 h-3 text-[#ff5a1f]" />
                    Password
                  </label>
                  <div className="relative">
                    <input
                      type={showRegPassword ? 'text' : 'password'}
                      required
                      placeholder="Min 4 chars"
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      className="w-full bg-black/70 border border-white/10 focus:border-[#ff5a1f] rounded-xl px-3.5 py-2.5 pr-8 text-xs text-white placeholder-zinc-600 focus:outline-none font-mono transition-colors"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegPassword(!showRegPassword)}
                      className="absolute right-2.5 top-2.5 text-zinc-500 hover:text-white transition-colors"
                      tabIndex={-1}
                    >
                      {showRegPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-zinc-300 mb-1 flex items-center gap-1.5">
                    <Lock className="w-3 h-3 text-[#ff5a1f]" />
                    Confirm Password
                  </label>
                  <input
                    type={showRegPassword ? 'text' : 'password'}
                    required
                    placeholder="Repeat password"
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    className="w-full bg-black/70 border border-white/10 focus:border-[#ff5a1f] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-600 focus:outline-none font-mono transition-colors"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 px-6 rounded-xl bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-bold tracking-widest uppercase transition-all shadow-xl shadow-[#ff5a1f]/25 flex items-center justify-center gap-2 group cursor-pointer disabled:opacity-50 mt-2"
              >
                {isSubmitting ? (
                  <span>Saving to Database...</span>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4" />
                    <span>Register to Database & Unlock</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </button>
            </form>
          )}

          {/* Security Notice */}
          <div className="pt-2 text-center text-[11px] text-zinc-500 leading-relaxed border-t border-white/5">
            Access protected by SHA-256 cryptographic verification & database access controls.
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 p-6 text-center text-[11px] text-zinc-600 border-t border-white/5">
        kali Haute Cuisine & Bar Group · 142 Regent Boulevard · Confidential Service Access
      </footer>
    </div>
  );
};
