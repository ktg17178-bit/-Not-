import React, { useEffect, useState } from 'react';
import { MenuItem } from '../types';
import { dbService } from '../services/db';
import { useCart } from '../context/CartContext';
import { ArrowRight, Flame, Award, Calendar, Sparkles, Plus, Check, Star, Wine, Shield, Eye, X } from 'lucide-react';

interface HomePageProps {
  onSelectTab: (tab: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onSelectTab }) => {
  const { addItem } = useCart();
  const [specialItems, setSpecialItems] = useState<MenuItem[]>([]);
  const [activeGalleryImage, setActiveGalleryImage] = useState<string | null>(null);
  const [addedMap, setAddedMap] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const loadSpecials = async () => {
      const items = await dbService.getMenuItems();
      const specials = items.filter(i => i.is_special).slice(0, 4);
      setSpecialItems(specials.length > 0 ? specials : items.slice(0, 4));
    };
    loadSpecials();
  }, []);

  const handleAddToCart = (item: MenuItem) => {
    addItem(item, 1);
    setAddedMap(prev => ({ ...prev, [item.id]: true }));
    setTimeout(() => {
      setAddedMap(prev => ({ ...prev, [item.id]: false }));
    }, 1600);
  };

  const galleryImages = [
    {
      url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=80',
      title: 'A5 Miyazaki Wagyu over Binchotan Charcoal',
      tag: 'Main Course'
    },
    {
      url: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=1200&q=80',
      title: 'Valrhona Grand Cru Smoked Caramel Sphere',
      tag: 'Pastry Atelier'
    },
    {
      url: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=1200&q=80',
      title: 'The Kali Obsidian Smoked Old Fashioned',
      tag: 'Mixology'
    },
    {
      url: 'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?auto=format&fit=crop&w=1200&q=80',
      title: 'The Grand Velvet Salon & Private Dining',
      tag: 'Ambiance'
    },
    {
      url: 'https://images.unsplash.com/photo-1578474846511-04ba529f0b88?auto=format&fit=crop&w=1200&q=80',
      title: 'Executive Hearth & Chef\'s Counter',
      tag: 'Kitchen'
    },
    {
      url: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=1200&q=80',
      title: 'Subterranean 400-Label Reserve Cellar',
      tag: 'Wine Vault'
    }
  ];

  return (
    <div className="space-y-24 pb-16">
      {/* 1. HERO SECTION */}
      <section className="relative min-h-[92vh] flex items-center justify-center overflow-hidden">
        {/* Background dark luxury image with overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=2000&q=85"
            alt="kali Luxury Dining Interior"
            className="w-full h-full object-cover opacity-30 scale-105 transform filter brightness-75 contrast-125"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/80 to-transparent" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#ff5a1f]/10 via-transparent to-transparent pointer-events-none" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-12">
          {/* Subtle Accolade Pill */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-md text-xs text-zinc-300 mb-8">
            <span className="w-2 h-2 rounded-full bg-[#ff5a1f]" />
            <span className="font-medium tracking-widest uppercase text-[10px]">
              Two Michelin Stars · 2026 Selection
            </span>
          </div>

          <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-serif-luxury font-bold tracking-tight text-white leading-none mb-6">
            Culinary Alchemy at <span className="text-[#ff5a1f] italic font-serif">kali</span>
          </h1>

          <p className="max-w-2xl mx-auto text-base sm:text-xl text-zinc-300 font-light leading-relaxed mb-10">
            An intimate five-star sanctuary where ancient wood-fired embers coalesce with avant-garde French technique and rare Japanese heritage ingredients.
          </p>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => onSelectTab('book')}
              className="w-full sm:w-auto px-8 py-4 rounded-full bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-semibold tracking-widest uppercase transition-all shadow-xl shadow-[#ff5a1f]/25 flex items-center justify-center gap-2 group cursor-pointer"
            >
              <Calendar className="w-4 h-4" />
              <span>Reserve Table Seating</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => onSelectTab('menu')}
              className="w-full sm:w-auto px-8 py-4 rounded-full bg-white/5 hover:bg-white/10 border border-white/15 text-white text-xs font-semibold tracking-widest uppercase transition-all backdrop-blur flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Explore Tasting Menu</span>
            </button>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-3 gap-6 max-w-xl mx-auto mt-16 pt-10 border-t border-white/10 text-center">
            <div>
              <span className="block text-2xl sm:text-3xl font-serif-luxury font-bold text-white">400+</span>
              <span className="text-[10px] uppercase tracking-wider text-zinc-400">Grand Cru Labels</span>
            </div>
            <div>
              <span className="block text-2xl sm:text-3xl font-serif-luxury font-bold text-[#ff5a1f]">A5</span>
              <span className="text-[10px] uppercase tracking-wider text-zinc-400">Miyazaki Beef</span>
            </div>
            <div>
              <span className="block text-2xl sm:text-3xl font-serif-luxury font-bold text-white">100%</span>
              <span className="text-[10px] uppercase tracking-wider text-zinc-400">Flame-Grilled Artisan</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. CHEF INTRO & PHILOSOPHY */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#121212] border border-white/10 rounded-3xl p-8 sm:p-14 relative overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Chef Portrait */}
            <div className="relative">
              <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/10 shadow-2xl relative">
                <img
                  src="https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&w=1200&q=80"
                  alt="Executive Chef Marco Kali"
                  className="w-full h-full object-cover filter contrast-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <span className="text-[11px] font-mono tracking-widest text-[#ff5a1f] uppercase block mb-1">
                    Atelier Founder & Master of Flame
                  </span>
                  <h3 className="text-2xl font-serif-luxury font-bold text-white">Chef Marco Kali</h3>
                  <p className="text-xs text-zinc-300">Former Head Chef, Le Crillon (Paris) & Nihonryori (Kyoto)</p>
                </div>
              </div>

              {/* Floating Award Badge */}
              <div className="absolute -bottom-4 -right-4 bg-black/90 border border-[#ff5a1f]/40 rounded-xl p-4 shadow-xl backdrop-blur-md hidden sm:flex items-center gap-3">
                <Award className="w-8 h-8 text-[#ff5a1f]" />
                <div>
                  <span className="block text-xs font-bold text-white uppercase tracking-wider">Chef of the Year</span>
                  <span className="text-[10px] text-zinc-400">Gastronomy Guild 2025</span>
                </div>
              </div>
            </div>

            {/* Philosophy Text */}
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 text-xs text-[#ff5a1f] font-semibold tracking-widest uppercase">
                <Flame className="w-4 h-4" />
                <span>The Culinary Manifesto</span>
              </div>

              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif-luxury font-bold text-white leading-tight">
                "Ingredients speak in whispers; the hearth elevates them to poetry."
              </h2>

              <p className="text-zinc-300 text-sm leading-relaxed">
                At kali, dining is not merely sustenance—it is a sensory ritual. Every evening, our kitchen ignites Japanese binchotan charcoal and foraged woods to coax profound nuances from pristine heirloom crops, sustainable line-caught seafood, and aged prime cattle.
              </p>

              <p className="text-zinc-400 text-xs leading-relaxed">
                Working in close tandem with Master Sommelier Elena Vance, each dish is calibrated to harmonize with our temperature-controlled cellar of rare biodynamic vintages and smoky bespoke botanicals.
              </p>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/10">
                <div className="space-y-1">
                  <span className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <Wine className="w-3.5 h-3.5 text-[#ff5a1f]" />
                    Cellar Mastery
                  </span>
                  <p className="text-[11px] text-zinc-400">Over 400 biodynamic and grand cru bottles curated for our tasting pairings.</p>
                </div>
                <div className="space-y-1">
                  <span className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-[#ff5a1f]" />
                    Uncompromising Origin
                  </span>
                  <p className="text-[11px] text-zinc-400">Single-origin Japanese Wagyu, foraged wild French morels, and certified caviar.</p>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => onSelectTab('chef')}
                  className="inline-flex items-center gap-2 text-xs uppercase font-semibold text-[#ff5a1f] hover:text-white transition-colors cursor-pointer"
                >
                  <span>Explore Chef Marco's Biography & Atelier</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. SIGNATURE HIGHLIGHTS (Data from Database) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <div className="inline-flex items-center gap-2 text-xs text-[#ff5a1f] font-semibold tracking-widest uppercase mb-2">
              <Sparkles className="w-4 h-4" />
              <span>Chef's Selected Specialties</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-white">
              Signature Gastronomy
            </h2>
            <p className="text-xs text-zinc-400 mt-2 max-w-xl">
              Dishes embodying the spirit of kali. Add to your tasting order or savor during your table reservation.
            </p>
          </div>

          <button
            onClick={() => onSelectTab('menu')}
            className="mt-4 md:mt-0 inline-flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-zinc-300 hover:text-[#ff5a1f] transition-colors cursor-pointer"
          >
            <span>View Full Menu & Categories</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Grid of Dishes */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {specialItems.map((item) => (
            <div
              key={item.id}
              className="bg-[#121212] border border-white/10 rounded-2xl overflow-hidden hover:border-[#ff5a1f]/50 transition-all flex flex-col group"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={item.image_url}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <span className="absolute top-3 left-3 px-2 py-0.5 rounded-full bg-black/70 backdrop-blur border border-white/10 text-[10px] text-zinc-300 font-medium">
                  {item.category}
                </span>
                {item.is_special && (
                  <span className="absolute top-3 right-3 px-2 py-0.5 rounded-full bg-[#ff5a1f] text-white text-[10px] font-bold uppercase tracking-wider">
                    Chef Choice
                  </span>
                )}
                <span className="absolute bottom-3 right-3 font-mono text-base font-bold text-white bg-black/60 px-2.5 py-1 rounded-lg backdrop-blur">
                  ${item.price}
                </span>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="text-base font-semibold text-white group-hover:text-[#ff5a1f] transition-colors leading-snug">
                    {item.name}
                  </h3>
                  <p className="text-xs text-zinc-400 mt-2 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                  <span className="text-[11px] text-zinc-500 font-mono">
                    {item.prep_time || '20 min'} · {item.calories || 450} kcal
                  </span>

                  <button
                    onClick={() => handleAddToCart(item)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                      addedMap[item.id]
                        ? 'bg-emerald-600 text-white'
                        : 'bg-zinc-800 hover:bg-[#ff5a1f] text-zinc-200 hover:text-white'
                    }`}
                  >
                    {addedMap[item.id] ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Added</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. CURATED GALLERY */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 text-xs text-[#ff5a1f] font-semibold tracking-widest uppercase mb-2">
            <Eye className="w-4 h-4" />
            <span>Visual Splendor</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-white">
            The kali Atmosphere & Craft
          </h2>
          <p className="text-xs text-zinc-400 mt-2">
            Click any frame to immerse yourself in our dining salon, cellar vaults, and plated masterpieces.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {galleryImages.map((img, idx) => (
            <div
              key={idx}
              onClick={() => setActiveGalleryImage(img.url)}
              className="relative aspect-square sm:aspect-[4/3] rounded-2xl overflow-hidden border border-white/10 group cursor-pointer"
            >
              <img
                src={img.url}
                alt={img.title}
                className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500 filter brightness-90 group-hover:brightness-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                <span className="text-[10px] text-[#ff5a1f] font-mono uppercase tracking-wider">{img.tag}</span>
                <span className="text-xs font-semibold text-white mt-0.5">{img.title}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox Modal */}
        {activeGalleryImage && (
          <div
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
            onClick={() => setActiveGalleryImage(null)}
          >
            <div className="relative max-w-4xl w-full" onClick={(e) => e.stopPropagation()}>
              <img
                src={activeGalleryImage}
                alt="Enlarged view"
                className="w-full max-h-[85vh] object-contain rounded-2xl border border-white/20 shadow-2xl"
              />
              <button
                onClick={() => setActiveGalleryImage(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/60 text-white hover:bg-[#ff5a1f] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}
      </section>

      {/* 5. CRITICAL ACCLAIM & REVIEWS */}
      <section className="border-y border-white/10 bg-[#0d0d0d] py-16">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
          <div className="flex justify-center gap-1 text-[#ff5a1f]">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-4 h-4 fill-[#ff5a1f]" />
            ))}
          </div>

          <blockquote className="text-xl sm:text-3xl font-serif-luxury font-medium text-white italic max-w-3xl mx-auto leading-relaxed">
            "kali redefines the pinnacle of modern gastronomy. The A5 Miyazaki Wagyu and foraged morels deliver an astonishing symphony of smokiness and delicacy seldom witnessed on any continent."
          </blockquote>

          <div className="flex flex-col items-center">
            <span className="text-sm font-semibold text-zinc-200 uppercase tracking-widest">
              The Michelin Guide Inspectorate
            </span>
            <span className="text-xs text-zinc-500">Exceptional Cuisine, Worth a Special Journey</span>
          </div>
        </div>
      </section>

      {/* 6. BOOKING BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-r from-[#18181b] via-[#121212] to-[#18181b] border border-white/10 p-8 sm:p-14 flex flex-col md:flex-row items-center justify-between gap-8 text-center md:text-left relative overflow-hidden">
          <div className="space-y-3 max-w-xl z-10">
            <span className="text-xs font-semibold text-[#ff5a1f] tracking-widest uppercase">
              Exclusive Dining Sessions
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif-luxury font-bold text-white">
              Securing Your Evening at kali
            </h2>
            <p className="text-xs text-zinc-400 leading-relaxed">
              We accommodate a limited number of guests per sitting to ensure unhurried culinary immersion. Reservations open 30 days in advance.
            </p>
          </div>

          <div className="z-10 flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => onSelectTab('book')}
              className="px-8 py-3.5 rounded-full bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-semibold tracking-wider uppercase transition-all shadow-xl shadow-[#ff5a1f]/25 cursor-pointer"
            >
              Reserve a Table
            </button>
            <button
              onClick={() => onSelectTab('contact')}
              className="px-6 py-3.5 rounded-full bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold tracking-wider uppercase transition-all border border-white/10 cursor-pointer"
            >
              Private Events Concierge
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
