import React, { useState, useEffect } from 'react';
import { MenuItem, MenuCategory } from '../types';
import { dbService } from '../services/db';
import { useCart } from '../context/CartContext';
import { Search, Plus, Check, Sparkles, Flame, Clock, Heart, Wine, X, Utensils, AlertCircle } from 'lucide-react';

interface MenuPageProps {
  onSelectTab: (tab: string) => void;
}

export const MenuPage: React.FC<MenuPageProps> = ({ onSelectTab }) => {
  const { addItem } = useCart();
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDish, setSelectedDish] = useState<MenuItem | null>(null);
  const [specialOnly, setSpecialOnly] = useState(false);
  const [addedMap, setAddedMap] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const fetchMenu = async () => {
      setLoading(true);
      const items = await dbService.getMenuItems();
      setMenuItems(items);
      setLoading(false);
    };
    fetchMenu();
  }, []);

  const categories = ['All', 'Veg', 'Non-Veg', 'Desserts', 'Drinks'];

  const filteredItems = menuItems.filter((item) => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSpecial = !specialOnly || item.is_special;
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSpecial && matchesSearch;
  });

  const handleAddToCart = (item: MenuItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    addItem(item, 1);
    setAddedMap(prev => ({ ...prev, [item.id]: true }));
    setTimeout(() => {
      setAddedMap(prev => ({ ...prev, [item.id]: false }));
    }, 1600);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* Page Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-[#ff5a1f] uppercase tracking-widest font-semibold">
          <Utensils className="w-3.5 h-3.5" />
          <span>Haute Cuisine Repertoire</span>
        </div>
        <h1 className="text-4xl sm:text-6xl font-serif-luxury font-bold text-white tracking-tight">
          The Tasting Menu
        </h1>
        <p className="text-sm text-zinc-400 font-light leading-relaxed">
          Crafted daily with seasonal provisions, binchotan wood smoke, and artisanal technique. All dishes available for table sittings and bespoke private service.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-[#121212] border border-white/10 rounded-2xl p-4 sm:p-6 space-y-4 shadow-xl">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-black/60 rounded-xl border border-white/5 w-full md:w-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 text-xs font-semibold rounded-lg uppercase tracking-wider transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#ff5a1f] text-white shadow-md'
                    : 'text-zinc-400 hover:text-white hover:bg-white/5'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3 pointer-events-none" />
            <input
              type="text"
              placeholder="Search wagyu, truffle, cocktail..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-black/60 border border-white/10 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#ff5a1f]"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-zinc-500 hover:text-zinc-300"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Secondary Toggles (Specials only) */}
        <div className="flex items-center justify-between pt-3 border-t border-white/5 text-xs text-zinc-400">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSpecialOnly(!specialOnly)}
              className={`flex items-center gap-2 px-3 py-1 rounded-lg border transition-all cursor-pointer ${
                specialOnly
                  ? 'bg-[#ff5a1f]/15 border-[#ff5a1f] text-[#ff5a1f] font-semibold'
                  : 'bg-black/30 border-white/10 text-zinc-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Chef's Specials Only</span>
            </button>
          </div>

          <span className="text-zinc-500 text-[11px] font-mono">
            Showing {filteredItems.length} of {menuItems.length} dishes
          </span>
        </div>
      </div>

      {/* Menu Grid */}
      {loading ? (
        <div className="text-center py-20 text-zinc-500">
          <div className="w-8 h-8 border-2 border-[#ff5a1f] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-xs uppercase tracking-widest">Retrieving culinary creations...</p>
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="text-center py-20 bg-[#121212] rounded-2xl border border-white/10 space-y-3">
          <Utensils className="w-8 h-8 text-zinc-600 mx-auto" />
          <h3 className="text-base font-semibold text-zinc-300">No dishes match your criteria</h3>
          <p className="text-xs text-zinc-500 max-w-sm mx-auto">
            Try adjusting your search keywords or resetting your category filters.
          </p>
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSearchQuery('');
              setSpecialOnly(false);
            }}
            className="px-4 py-2 bg-zinc-800 text-white rounded-lg text-xs font-semibold hover:bg-zinc-700"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => setSelectedDish(item)}
              className="bg-[#121212] border border-white/10 rounded-2xl overflow-hidden hover:border-[#ff5a1f]/60 transition-all flex flex-col group cursor-pointer shadow-lg hover:shadow-2xl"
            >
              {/* Image Banner */}
              <div className="relative aspect-[16/10] overflow-hidden bg-black">
                <img
                  src={item.image_url}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

                {/* Category & Badge */}
                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-black/80 backdrop-blur border border-white/15 text-[10px] text-zinc-200 font-medium">
                    {item.category}
                  </span>
                  {item.is_special && (
                    <span className="px-2.5 py-0.5 rounded-full bg-[#ff5a1f] text-white text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 shadow-sm">
                      <Sparkles className="w-2.5 h-2.5" />
                      Signature
                    </span>
                  )}
                </div>

                {/* Price */}
                <div className="absolute bottom-3 right-3 font-mono text-lg font-bold text-white bg-black/75 px-3 py-1 rounded-lg backdrop-blur border border-white/10">
                  ${item.price}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="text-lg font-serif-luxury font-bold text-white group-hover:text-[#ff5a1f] transition-colors">
                    {item.name}
                  </h3>
                  <p className="text-xs text-zinc-400 mt-2 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                {/* Meta details */}
                <div className="pt-3 border-t border-white/5 flex items-center justify-between text-[11px] text-zinc-400">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-zinc-500" />
                      {item.prep_time || '20 min'}
                    </span>
                    {item.allergens && item.allergens.length > 0 && (
                      <span className="text-zinc-500">
                        {item.allergens.join(', ')}
                      </span>
                    )}
                  </div>

                  {/* Add Button */}
                  <button
                    onClick={(e) => handleAddToCart(item, e)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                      addedMap[item.id]
                        ? 'bg-emerald-600 text-white'
                        : 'bg-[#ff5a1f] hover:bg-[#e04b14] text-white shadow-md shadow-[#ff5a1f]/20'
                    }`}
                  >
                    {addedMap[item.id] ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Added</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add to Order</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Dish Detail Modal */}
      {selectedDish && (
        <div
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setSelectedDish(null)}
        >
          <div
            className="relative max-w-2xl w-full bg-[#121212] border border-white/15 rounded-3xl overflow-hidden shadow-2xl text-white"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Image */}
            <div className="relative aspect-video w-full">
              <img
                src={selectedDish.image_url}
                alt={selectedDish.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-transparent" />
              <button
                onClick={() => setSelectedDish(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/60 text-white hover:bg-[#ff5a1f] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="absolute bottom-4 left-6 right-6 flex items-end justify-between">
                <div>
                  <span className="text-xs uppercase tracking-widest text-[#ff5a1f] font-semibold">
                    {selectedDish.category}
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-serif-luxury font-bold text-white">
                    {selectedDish.name}
                  </h2>
                </div>
                <span className="text-2xl font-mono font-bold text-white bg-black/60 px-3 py-1 rounded-xl">
                  ${selectedDish.price}
                </span>
              </div>
            </div>

            {/* Modal Details */}
            <div className="p-6 space-y-6">
              <p className="text-sm text-zinc-300 leading-relaxed">
                {selectedDish.description}
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-black/50 border border-white/5 text-xs">
                <div>
                  <span className="text-zinc-500 block">Preparation Time</span>
                  <span className="font-semibold text-zinc-200">{selectedDish.prep_time || '20 min'}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block">Caloric Value</span>
                  <span className="font-semibold text-zinc-200">{selectedDish.calories || 450} kcal</span>
                </div>
                <div>
                  <span className="text-zinc-500 block">Allergens</span>
                  <span className="font-semibold text-zinc-200">
                    {selectedDish.allergens?.length ? selectedDish.allergens.join(', ') : 'None notified'}
                  </span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#ff5a1f]/10 border border-[#ff5a1f]/20 flex items-start gap-3">
                <Wine className="w-4 h-4 text-[#ff5a1f] mt-0.5 flex-shrink-0" />
                <div className="text-xs">
                  <span className="font-semibold text-white">Sommelier's Recommended Pairing</span>
                  <p className="text-zinc-400 mt-0.5">
                    Recommended with a glass of Domaine de la Romanée-Conti vintage or our house obsidian smoked old fashioned.
                  </p>
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => {
                    handleAddToCart(selectedDish);
                    setSelectedDish(null);
                  }}
                  className="flex-1 py-3 px-4 rounded-xl bg-[#ff5a1f] hover:bg-[#e04b14] text-white text-xs font-semibold uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#ff5a1f]/20 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add to Tasting Course</span>
                </button>
                <button
                  onClick={() => {
                    setSelectedDish(null);
                    onSelectTab('book');
                  }}
                  className="px-6 py-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer"
                >
                  Reserve Table
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
